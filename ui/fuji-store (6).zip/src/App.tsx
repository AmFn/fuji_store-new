/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Virtuoso, VirtuosoGrid } from 'react-virtuoso';
import { toJpeg } from 'html-to-image';
import { 
  Images, 
  Clock, 
  Heart, 
  Tags, 
  EyeOff, 
  BarChart3, 
  FlaskConical, 
  Plus, 
  Search, 
  LayoutGrid, 
  List, 
  Filter, 
  ArrowUpDown,
  Settings,
  X,
  Camera,
  Calendar,
  Info,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Loader2,
  Trash2,
  Star,
  Sparkles,
  Download,
  ExternalLink,
  Folder as FolderIcon,
  RefreshCw,
  Edit2,
  FolderPlus,
  Layout,
  Image as ImageIcon,
  Palette,
  Share2,
  Check,
  Film,
  Edit3,
  Sun,
  Zap,
  Target,
  Moon,
  Layers,
  Droplets,
  Eye,
  Plane,
  HardDrive,
  RotateCcw,
  Navigation
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import exifr from 'exifr';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

import { cn } from './lib/utils';
import { Photo, Recipe, Tag, Folder } from './types';

// Mock User Type
interface User {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
}

// --- Constants ---
const FILM_MODES = [
  'Provia/Standard', 'Velvia/Vivid', 'Astia/Soft', 'Classic Chrome', 
  'PRO Neg. Hi', 'PRO Neg. Std', 'Classic Neg.', 'Nostalgic Neg.',
  'Eterna/Cinema', 'Eterna Bleach Bypass', 'Acros', 'Monochrome', 'Sepia',
  'Reala Ace'
];

const FILM_SHORT_CODES: Record<string, string> = {
  'Provia/Standard': 'STD',
  'Velvia/Vivid': 'V',
  'Astia/Soft': 'S',
  'Classic Chrome': 'CC',
  'PRO Neg. Hi': 'NH',
  'PRO Neg. Std': 'NS',
  'Classic Neg.': 'NC',
  'Nostalgic Neg.': 'NN',
  'Eterna/Cinema': 'E',
  'Eterna Bleach Bypass': 'EBB',
  'Acros': 'A',
  'Monochrome': 'M',
  'Sepia': 'SEP',
  'Reala Ace': 'RA'
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// --- Components ---

export default function App() {
  const [user, setUser] = useState<User | null>({ 
    uid: 'demo', 
    email: 'feng46042@gmail.com', 
    displayName: 'Fuji User',
    photoURL: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Fuji'
  } as any);
  const [loading, setLoading] = useState(false);
  const [activeView, setActiveView] = useState<'photos' | 'timeline' | 'recipes' | 'stats' | 'settings' | 'favorites' | 'hidden' | 'tags' | 'posters' | 'templates'>('photos');
  const [importModalInitialType, setImportModalInitialType] = useState<'files' | 'folders'>('files');
  const [photos, setPhotos] = useState<Photo[]>(() => {
    const mockPhotos: Photo[] = [];
    const dates = [
      { label: 'Today', offset: 0 },
      { label: 'Yesterday', offset: 86400000 },
      { label: '2 Days Ago', offset: 172800000 },
      { label: '3 Days Ago', offset: 259200000 },
      { label: '4 Days Ago', offset: 345600000 },
      { label: '5 Days Ago', offset: 432000000 },
      { label: '6 Days Ago', offset: 518400000 }
    ];

    const cameras = ['X-T5', 'X100VI', 'X-Pro3', 'X-H2s', 'GFX100 II', 'X-E4'];
    const modes = ['Classic Neg.', 'Classic Chrome', 'Acros', 'Reala Ace', 'Nostalgic Neg.', 'Velvia/Vivid'];
    const tagsList = ['Street', 'Travel', 'Portrait', 'Nature', 'Landscape', 'Architecture', 'Night', 'B&W'];

    dates.forEach((dateInfo, dIdx) => {
      for (let i = 1; i <= 15; i++) {
        const id = `mock-${dIdx}-${i}`;
        mockPhotos.push({
          id,
          fileName: `DSCF${1000 + dIdx * 100 + i}.JPG`,
          filePath: `DSCF${1000 + dIdx * 100 + i}.JPG`,
          thumbnailUrl: `https://picsum.photos/seed/fuji-${id}/800/800`,
          cameraModel: cameras[Math.floor(Math.random() * cameras.length)],
          filmMode: modes[Math.floor(Math.random() * modes.length)],
          dateTime: new Date(Date.now() - dateInfo.offset - (i * 3600000)).toISOString(),
          isFavorite: Math.random() > 0.7,
          isHidden: false,
          rating: Math.floor(Math.random() * 3) + 3,
          tags: [tagsList[Math.floor(Math.random() * tagsList.length)], tagsList[Math.floor(Math.random() * tagsList.length)]].filter((v, i, a) => a.indexOf(v) === i),
          ownerId: 'demo'
        });
      }
    });
    return mockPhotos;
  });
  const [recipes, setRecipes] = useState<Recipe[]>([
    {
      id: 'r1',
      name: 'Kodak Portra 400',
      description: 'Warm and nostalgic tones for street photography.',
      filmMode: 'Classic Chrome',
      whiteBalance: 'Auto',
      dynamicRange: 'DR400',
      sharpness: '-2',
      saturation: '+1',
      contrast: '-1',
      clarity: '-2',
      shadowTone: '+1',
      highlightTone: '-1',
      noiseReduction: '-4',
      grainEffect: 'Strong',
      isFavorite: true,
      ownerId: 'demo'
    },
    {
      id: 'r2',
      name: 'Cinestill 800T',
      description: 'Cool shadows and glowing highlights for night shots.',
      filmMode: 'Eterna',
      whiteBalance: '3200K',
      dynamicRange: 'DR200',
      sharpness: '0',
      saturation: '+2',
      contrast: '+1',
      clarity: '0',
      shadowTone: '+2',
      highlightTone: '+1',
      noiseReduction: '-2',
      grainEffect: 'Weak',
      isFavorite: false,
      ownerId: 'demo'
    },
    {
      id: 'r3',
      name: 'Tri-X 400',
      description: 'High contrast black and white with deep blacks.',
      filmMode: 'Acros',
      whiteBalance: 'Auto',
      dynamicRange: 'DR100',
      sharpness: '+1',
      saturation: 'N/A',
      contrast: '+2',
      clarity: '+1',
      shadowTone: '+2',
      highlightTone: '+2',
      noiseReduction: '-4',
      grainEffect: 'Strong',
      isFavorite: true,
      ownerId: 'demo'
    },
    {
      id: 'r4',
      name: 'Fujicolor Superia 400',
      description: 'Greenish tints and natural skin tones.',
      filmMode: 'Classic Neg.',
      whiteBalance: 'Daylight',
      dynamicRange: 'DR200',
      sharpness: '0',
      saturation: '0',
      contrast: '+1',
      clarity: '0',
      shadowTone: '+1',
      highlightTone: '0',
      noiseReduction: '-2',
      grainEffect: 'Weak',
      isFavorite: false,
      ownerId: 'demo'
    },
    {
      id: 'r5',
      name: 'Kodak Gold 200',
      description: 'Warm, golden tones with a classic film look.',
      filmMode: 'Classic Chrome',
      whiteBalance: 'Auto',
      dynamicRange: 'DR200',
      sharpness: '-1',
      saturation: '+2',
      contrast: '0',
      clarity: '-1',
      shadowTone: '0',
      highlightTone: '+1',
      noiseReduction: '-4',
      grainEffect: 'Weak',
      isFavorite: true,
      ownerId: 'demo'
    },
    {
      id: 'r6',
      name: 'Eterna Cinema',
      description: 'Soft tones and low saturation for a cinematic look.',
      filmMode: 'Eterna',
      whiteBalance: 'Auto',
      dynamicRange: 'DR400',
      sharpness: '-1',
      saturation: '-2',
      contrast: '-1',
      clarity: '0',
      shadowTone: '0',
      highlightTone: '-1',
      noiseReduction: '0',
      grainEffect: 'Off',
      isFavorite: false,
      ownerId: 'demo'
    },
    {
      id: 'r7',
      name: 'Classic Negative Street',
      description: 'High contrast and unique color shifts for urban scenes.',
      filmMode: 'Classic Neg.',
      whiteBalance: 'Auto',
      dynamicRange: 'DR200',
      sharpness: '+1',
      saturation: '0',
      contrast: '+2',
      clarity: '+1',
      shadowTone: '+1',
      highlightTone: '+1',
      noiseReduction: '-2',
      grainEffect: 'Weak',
      isFavorite: true,
      ownerId: 'demo'
    },
    {
      id: 'r8',
      name: 'Astia Portrait',
      description: 'Soft skin tones and vibrant colors for portraits.',
      filmMode: 'Astia/Soft',
      whiteBalance: 'Daylight',
      dynamicRange: 'DR100',
      sharpness: '0',
      saturation: '+1',
      contrast: '-1',
      clarity: '-1',
      shadowTone: '-1',
      highlightTone: '0',
      noiseReduction: '0',
      grainEffect: 'Off',
      isFavorite: false,
      ownerId: 'demo'
    }
  ]);
  const [tags, setTags] = useState<Tag[]>([
    { id: 't1', name: 'Street', color: '#3b82f6', ownerId: 'demo' },
    { id: 't2', name: 'Travel', color: '#10b981', ownerId: 'demo' },
    { id: 't3', name: 'Portrait', color: '#f59e0b', ownerId: 'demo' },
    { id: 't4', name: 'Nature', color: '#8b5cf6', ownerId: 'demo' },
    { id: 't5', name: 'B&W', color: '#64748b', ownerId: 'demo' },
    { id: 't6', name: 'Night', color: '#1e293b', ownerId: 'demo' },
    { id: 't7', name: 'Landscape', color: '#065f46', ownerId: 'demo' },
    { id: 't8', name: 'Architecture', color: '#92400e', ownerId: 'demo' },
    { id: 't9', name: 'Macro', color: '#be185d', ownerId: 'demo' },
    { id: 't10', name: 'Wildlife', color: '#15803d', ownerId: 'demo' },
    { id: 't11', name: 'Cityscape', color: '#0369a1', ownerId: 'demo' },
    { id: 't12', name: 'Vibrant', color: '#e11d48', ownerId: 'demo' },
    { id: 't13', name: 'Vintage', color: '#78350f', ownerId: 'demo' },
    { id: 't14', name: 'Cinematic', color: '#4338ca', ownerId: 'demo' },
    { id: 't15', name: 'Golden Hour', color: '#ea580c', ownerId: 'demo' },
    { id: 't16', name: 'Europe', color: '#0891b2', ownerId: 'demo' },
    { id: 't17', name: 'Mountains', color: '#334155', ownerId: 'demo' },
    { id: 't18', name: 'Food', color: '#db2777', ownerId: 'demo' },
    { id: 't19', name: 'Fashion', color: '#7c3aed', ownerId: 'demo' },
    { id: 't20', name: 'Studio', color: '#475569', ownerId: 'demo' },
    { id: 't21', name: 'Macro', color: '#be185d', ownerId: 'demo' },
    { id: 't22', name: 'Wildlife', color: '#15803d', ownerId: 'demo' },
    { id: 't23', name: 'Cityscape', color: '#0369a1', ownerId: 'demo' },
    { id: 't24', name: 'Vibrant', color: '#e11d48', ownerId: 'demo' },
    { id: 't25', name: 'Vintage', color: '#78350f', ownerId: 'demo' },
    { id: 't26', name: 'Japan', color: '#ef4444', ownerId: 'demo' },
    { id: 't27', name: 'Rain', color: '#3b82f6', ownerId: 'demo' },
    { id: 't28', name: 'Minimal', color: '#94a3b8', ownerId: 'demo' },
    { id: 't29', name: 'Flowers', color: '#ec4899', ownerId: 'demo' },
    { id: 't30', name: 'Tokyo', color: '#f43f5e', ownerId: 'demo' }
  ]);
  const [tagSearchQuery, setTagSearchQuery] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [syncFolderId, setSyncFolderId] = useState<string | null>(null);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [exportPhoto, setExportPhoto] = useState<Photo | null>(null);
  const [initialExportTemplate, setInitialExportTemplate] = useState('minimal');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filterFilmMode, setFilterFilmMode] = useState('All');
  const [filterExtension, setFilterExtension] = useState<'JPG' | 'RAF' | 'All'>('JPG');
  const [filterDate, setFilterDate] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isAdvancedFilterOpen, setIsAdvancedFilterOpen] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'date' | 'size'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  const [folders, setFolders] = useState<Folder[]>([
    { id: '1', name: '2024 Spring Trip', path: '/Users/fuji/Photos/2024_Spring', type: 'physical', includeSubfolders: true, photoCount: 124, lastSynced: new Date().toISOString() },
    { id: '2', name: 'Street Photography', path: '/Users/fuji/Photos/Street', type: 'physical', includeSubfolders: false, photoCount: 89, lastSynced: new Date().toISOString() },
    { id: '3', name: 'Family Portraits', path: '/Users/fuji/Photos/Family', type: 'physical', includeSubfolders: true, photoCount: 45, lastSynced: new Date().toISOString() },
    { id: '4', name: 'Commercial Work', path: '/Users/fuji/Photos/Commercial', type: 'physical', includeSubfolders: true, photoCount: 210, lastSynced: new Date().toISOString() },
    { id: '5', name: 'Personal Archive', path: '/Users/fuji/Photos/Archive', type: 'physical', includeSubfolders: true, photoCount: 1540, lastSynced: new Date().toISOString() },
    { id: '6', name: 'Experimental', path: '/Users/fuji/Photos/Experimental', type: 'logical', includeSubfolders: false, photoCount: 32, lastSynced: new Date().toISOString() },
  ]);
  const [cloudSyncEnabled, setCloudSyncEnabled] = useState(false);

  useEffect(() => {
    const savedTheme = localStorage.getItem('fuji-theme') as 'light' | 'dark';
    if (savedTheme) setTheme(savedTheme);
  }, []);

  useEffect(() => {
    localStorage.setItem('fuji-theme', theme);
  }, [theme]);

  const handleRecognizeRecipe = async (photo: Photo) => {
    try {
      // Fetch the image as base64
      const imgResponse = await fetch(photo.thumbnailUrl);
      const blob = await imgResponse.blob();
      const base64Data = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(blob);
      });

      const prompt = `
        Analyze this Fujifilm photo and its metadata to recognize the specific Film Simulation Recipe used.
        Use official Fujifilm parameter names and values.
        
        Metadata provided:
        - Camera: ${photo.cameraModel}
        - Film Mode: ${photo.filmMode}
        - White Balance: ${photo.whiteBalance}
        - Dynamic Range: ${photo.dynamicRange}
        - Sharpness: ${photo.sharpness}
        - Saturation/Color: ${photo.saturation}
        - Contrast: ${photo.contrast}
        - Clarity: ${photo.clarity}
        - Shadow Tone: ${photo.shadowTone}
        - Highlight Tone: ${photo.highlightTone}
        - Noise Reduction: ${photo.noiseReduction}
        - Grain Effect: ${photo.grainEffect}
        
        Analyze this Fujifilm photograph and its metadata to identify the specific film simulation recipe used.
        Fujifilm cameras have very specific parameters. Please identify:
        1. Film Simulation (e.g., Classic Chrome, Acros, Provia, Velvia, Astia, Classic Neg, Nostalgic Neg, Eterna, Eterna Bleach Bypass)
        2. White Balance (e.g., Auto, Daylight, Shade, Fluorescent, Incandescent, Underwater, or Color Temperature in K)
        3. White Balance Shift (R: -9 to +9, B: -9 to +9)
        4. Dynamic Range (DR100, DR200, DR400)
        5. Highlight Tone (-2 to +4)
        6. Shadow Tone (-2 to +4)
        7. Color (Saturation) (-4 to +4)
        8. Sharpness (-4 to +4)
        9. Noise Reduction (-4 to +4)
        10. Clarity (-5 to +5)
        11. Grain Effect (Off, Weak, Strong) and Size (Small, Large)
        12. Color Chrome Effect (Off, Weak, Strong)
        13. Color Chrome Effect Blue (FX Blue) (Off, Weak, Strong)
        
        If you cannot find the exact value, provide your best estimate based on the visual characteristics (contrast, saturation, grain, color cast).
        Return the result in JSON format with these exact keys: name, description, filmMode, whiteBalance, dynamicRange, sharpness, color, contrast, clarity, shadowTone, highlightTone, noiseReduction, grainEffect, colorChromeEffect, colorChromeEffectBlue.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            parts: [
              { text: prompt },
              { inlineData: { data: base64Data, mimeType: "image/jpeg" } }
            ]
          }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              filmMode: { type: Type.STRING },
              whiteBalance: { type: Type.STRING },
              dynamicRange: { type: Type.STRING },
              sharpness: { type: Type.STRING },
              color: { type: Type.STRING },
              contrast: { type: Type.STRING },
              clarity: { type: Type.STRING },
              shadowTone: { type: Type.STRING },
              highlightTone: { type: Type.STRING },
              noiseReduction: { type: Type.STRING },
              grainEffect: { type: Type.STRING },
              colorChromeEffect: { type: Type.STRING },
              colorChromeEffectBlue: { type: Type.STRING }
            }
          }
        }
      });

      const recipeData = JSON.parse(response.text);
      const newRecipe: Recipe = {
        id: `r-${Date.now()}`,
        ...recipeData,
        isFavorite: false,
        ownerId: user?.uid || 'demo'
      };
      setRecipes(prev => [...prev, newRecipe]);
      alert('Recipe recognized and saved!');
    } catch (err) {
      console.error('Error recognizing recipe:', err);
      alert('Failed to recognize recipe.');
    }
  };

  useEffect(() => {
    // Mock sync effect
    console.log('Mock data sync initialized');
  }, [user]);

  const filteredPhotos = photos.filter(p => {
    const matchesSearch = p.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         p.cameraModel?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         p.filmMode?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilm = filterFilmMode === 'All' || p.filmMode === filterFilmMode;
    const matchesExtension = filterExtension === 'All' || p.fileName.toUpperCase().endsWith(`.${filterExtension}`);
    const matchesDate = !filterDate || p.dateTime?.startsWith(filterDate);
    const matchesTags = selectedTags.length === 0 || selectedTags.every(tag => p.tags?.includes(tag));
    const matchesFolder = !activeFolderId || p.folderId === activeFolderId;
    
    const matchesView = activeView === 'photos' ? true :
                       activeView === 'favorites' ? p.isFavorite :
                       true;
    return matchesSearch && matchesFilm && matchesExtension && matchesDate && matchesTags && matchesFolder && matchesView;
  }).sort((a, b) => {
    let comparison = 0;
    if (sortBy === 'name') {
      comparison = a.fileName.localeCompare(b.fileName);
    } else if (sortBy === 'date') {
      comparison = new Date(a.dateTime || '').getTime() - new Date(b.dateTime || '').getTime();
    } else if (sortBy === 'size') {
      comparison = parseInt(a.size || '0') - parseInt(b.size || '0');
    }
    return sortOrder === 'asc' ? comparison : -comparison;
  });

  const handleFolderRename = async (id: string) => {
    const folder = folders.find(f => f.id === id);
    if (!folder) return;
    const newName = window.prompt('Enter new folder name:', folder.name);
    if (newName && newName !== folder.name) {
      setFolders(prev => prev.map(f => f.id === id ? { ...f, name: newName } : f));
    }
  };

  const handleFolderAddSubfolder = async (parentId: string) => {
    const parent = folders.find(f => f.id === parentId);
    const newName = window.prompt(`Enter subfolder name for "${parent?.name}":`, 'New Subfolder');
    if (newName) {
      const newFolder: Folder = {
        id: `f-${Date.now()}`,
        name: newName,
        parentId: parentId,
        path: `${parent?.path}/${newName}`,
        type: parent?.type || 'physical',
        includeSubfolders: true,
        photoCount: 0,
        lastSynced: new Date().toISOString()
      };
      setFolders(prev => [...prev, newFolder]);
    }
  };

  const handleFolderAddFiles = (id: string) => {
    setActiveFolderId(id);
    setImportModalInitialType('files');
    setIsImportModalOpen(true);
  };

  const handleFolderReorder = (draggedId: string, targetId: string) => {
    setFolders(prev => {
      const next = [...prev];
      const draggedIdx = next.findIndex(f => f.id === draggedId);
      const targetIdx = next.findIndex(f => f.id === targetId);
      if (draggedIdx !== -1 && targetIdx !== -1) {
        const [removed] = next.splice(draggedIdx, 1);
        next.splice(targetIdx, 0, removed);
      }
      return next;
    });
  };

  const handleUpdatePhoto = (id: string, updates: Partial<Photo>) => {
    setPhotos(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const handleToggleFavorite = (id: string) => {
    setPhotos(prev => prev.map(p => p.id === id ? { ...p, isFavorite: !p.isFavorite } : p));
  };

  const handleDeletePhoto = (id: string) => {
    setPhotos(prev => prev.filter(p => p.id !== id));
  };

  const handleDeleteTag = (tagId: string) => {
    if (window.confirm('Are you sure you want to delete this tag? This will remove it from all photos.')) {
      const tag = tags.find(t => t.id === tagId);
      if (tag) {
        setTags(prev => prev.filter(t => t.id !== tagId));
        setPhotos(prev => prev.map(p => ({
          ...p,
          tags: p.tags?.filter(t => t !== tag.name) || []
        })));
      }
    }
  };

  const handleAddTag = (tag: Tag) => {
    setTags(prev => [...prev, tag]);
  };

  const handleAddRecipe = (recipe: Recipe) => {
    setRecipes(prev => [...prev, recipe]);
  };

  const handleUpdateFolder = (id: string, updates: Partial<Folder>) => {
    setFolders(prev => prev.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  return (
    <div className={cn(
      "h-screen w-screen flex overflow-hidden font-sans transition-colors duration-300",
      theme === 'dark' ? "dark bg-[#0a0a0a] text-white" : "bg-slate-50 text-slate-900"
    )}>
      {/* Sidebar */}
      <aside className="w-64 border-r border-[var(--border-color)] flex flex-col bg-[var(--bg-secondary)]/50 backdrop-blur-xl">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Images className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-indigo-600">Fuji Store</span>
        </div>

        <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
          <NavItem 
            icon={<Images className="w-4 h-4" />} 
            label="All Photos" 
            active={activeView === 'photos'} 
            onClick={() => setActiveView('photos')} 
            theme={theme}
          />
          <NavItem 
            icon={<Clock className="w-4 h-4" />} 
            label="Timeline" 
            active={activeView === 'timeline'} 
            onClick={() => setActiveView('timeline')} 
            theme={theme}
          />
          <NavItem 
            icon={<Heart className="w-4 h-4" />} 
            label="Favorites" 
            active={activeView === 'favorites'} 
            onClick={() => setActiveView('favorites')} 
            theme={theme}
          />
          <NavItem 
            icon={<Tags className="w-4 h-4" />} 
            label="Tags" 
            active={activeView === 'tags'} 
            onClick={() => setActiveView('tags')} 
            theme={theme}
          />
          <NavItem 
            icon={<BarChart3 className="w-4 h-4" />} 
            label="Stats" 
            active={activeView === 'stats'} 
            onClick={() => setActiveView('stats')} 
            theme={theme}
          />
          <NavItem 
            icon={<FlaskConical className="w-4 h-4" />} 
            label="Recipes" 
            active={activeView === 'recipes'} 
            onClick={() => setActiveView('recipes')} 
            theme={theme}
          />
          <NavItem 
            icon={<Palette className="w-4 h-4" />} 
            label="Templates" 
            active={activeView === 'templates'} 
            onClick={() => setActiveView('templates')} 
            theme={theme}
          />

          <div className="pt-8 pb-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center justify-between">
            Directories
            <button 
              onClick={() => {
                setImportModalInitialType('folders');
                setIsImportModalOpen(true);
              }}
              className="p-1 hover:bg-slate-500/10 rounded-md transition-colors"
            >
              <Plus className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-1 px-2">
            <DirectoryTree 
              folders={folders} 
              activeFolderId={activeFolderId}
              onFolderSelect={(id) => {
                setActiveFolderId(id);
                setActiveView('photos');
              }}
              onRefresh={(id) => {
                setSyncFolderId(id);
                setIsSyncModalOpen(true);
              }} 
              onRename={handleFolderRename}
              onAddSubfolder={handleFolderAddSubfolder}
              onAddFiles={handleFolderAddFiles}
              onReorder={handleFolderReorder}
              photos={photos} 
              onUpdatePhoto={handleUpdatePhoto}
            />
          </div>
        </nav>

        <div className="p-4 border-t border-[var(--border-color)] space-y-4">
          <div className="flex items-center gap-3 px-2">
            <img src={user.photoURL || ''} className="w-8 h-8 rounded-full border border-blue-500/20" alt="User" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate">{user.displayName}</p>
              <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
            </div>
            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 hover:bg-blue-500/10 rounded-lg transition-colors text-blue-500"
            >
              {theme === 'dark' ? <Star className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
            </button>
          </div>
          <button 
            onClick={() => setActiveView('settings')}
            className={cn(
              "w-full py-2 flex items-center justify-center gap-2 text-xs font-semibold transition-colors rounded-lg",
              activeView === 'settings' ? "bg-blue-500 text-white shadow-lg shadow-blue-500/20" : "text-slate-400 hover:text-blue-500 hover:bg-blue-500/5"
            )}
          >
            <Settings className="w-3.5 h-3.5" />
            Settings
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative overflow-hidden bg-[var(--bg-primary)]">
        {/* Header / Toolbar - Conditionally rendered */}
        {(activeView === 'photos' || activeView === 'favorites') && (
          <header className="h-20 border-b border-[var(--border-color)] flex items-center justify-between px-8 bg-[var(--bg-primary)]/80 backdrop-blur-xl sticky top-0 z-10">
            <div className="flex items-center gap-6 flex-1 max-w-2xl">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search photos, models, recipes..." 
                  className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-2xl py-2.5 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex items-center bg-slate-500/5 border border-[var(--border-color)] rounded-xl p-1">
                <button 
                  onClick={() => setViewMode('grid')}
                  className={cn("p-2 rounded-lg transition-all", viewMode === 'grid' ? "bg-white text-blue-600 shadow-sm dark:bg-white/10 dark:text-white" : "text-slate-400 hover:text-slate-600")}
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setViewMode('list')}
                  className={cn("p-2 rounded-lg transition-all", viewMode === 'list' ? "bg-white text-blue-600 shadow-sm dark:bg-white/10 dark:text-white" : "text-slate-400 hover:text-slate-600")}
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center bg-slate-500/5 border border-[var(--border-color)] rounded-xl p-1">
                <button 
                  onClick={() => setFilterExtension('JPG')}
                  className={cn("px-3 py-1.5 rounded-lg text-xs font-black transition-all", filterExtension === 'JPG' ? "bg-blue-500 text-white shadow-sm" : "text-slate-400 hover:text-slate-600")}
                >
                  JPG
                </button>
                <button 
                  onClick={() => setFilterExtension('RAF')}
                  className={cn("px-3 py-1.5 rounded-lg text-xs font-black transition-all", filterExtension === 'RAF' ? "bg-blue-500 text-white shadow-sm" : "text-slate-400 hover:text-slate-600")}
                >
                  RAF
                </button>
                <button 
                  onClick={() => setFilterExtension('All')}
                  className={cn("px-3 py-1.5 rounded-lg text-xs font-black transition-all", filterExtension === 'All' ? "bg-blue-500 text-white shadow-sm" : "text-slate-400 hover:text-slate-600")}
                >
                  ALL
                </button>
              </div>
              
              <button 
                onClick={() => setIsAdvancedFilterOpen(!isAdvancedFilterOpen)}
                className={cn(
                  "p-2.5 rounded-xl border transition-all flex items-center gap-2 text-sm font-bold",
                  isAdvancedFilterOpen ? "bg-blue-500/10 border-blue-500/30 text-blue-500" : "bg-slate-500/5 border-[var(--border-color)] text-slate-500 hover:bg-slate-500/10"
                )}
              >
                <Filter className="w-4 h-4" />
                Advanced
              </button>

              <button 
                onClick={() => {
                  setImportModalInitialType('files');
                  setIsImportModalOpen(true);
                }}
                className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-lg shadow-blue-500/20"
              >
                <Plus className="w-4 h-4" />
                Import
              </button>
            </div>
          </header>
        )}

        {/* Advanced Filters */}
        <AnimatePresence>
          {isAdvancedFilterOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="border-b border-[var(--border-color)] bg-[var(--bg-secondary)]/30 backdrop-blur-md overflow-hidden"
            >
              <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-6 max-w-6xl">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Date Filter</label>
                    {filterDate && (
                      <button 
                        onClick={() => setFilterDate('')}
                        className="text-[10px] font-black text-blue-500 uppercase tracking-widest hover:underline"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                  <CustomDatePicker 
                    value={filterDate}
                    onChange={setFilterDate}
                  />
                  <div className="flex flex-wrap gap-2 mt-2">
                    {[
                      { label: 'All', value: '' },
                      { label: 'Today', value: new Date().toISOString().split('T')[0] },
                      { label: '7 Days', value: new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0] },
                      { label: 'Month', value: new Date().toISOString().slice(0, 7) }
                    ].map(opt => (
                      <button
                        key={opt.label}
                        onClick={() => setFilterDate(opt.value)}
                        className={cn(
                          "px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border transition-all flex items-center gap-1.5",
                          (opt.value === '' ? filterDate === '' : filterDate.startsWith(opt.value))
                            ? "bg-blue-500 border-blue-500 text-white shadow-lg shadow-blue-500/20 scale-105" 
                            : "bg-slate-500/5 border-[var(--border-color)] text-slate-400 hover:border-blue-500/30 hover:bg-slate-500/10"
                        )}
                      >
                        <div className={cn("w-1 h-1 rounded-full", (opt.value === '' ? filterDate === '' : filterDate.startsWith(opt.value)) ? "bg-white" : "bg-slate-400")} />
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 col-span-1 md:col-span-2 lg:col-span-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Film Simulation</label>
                    {filterFilmMode !== 'All' && (
                      <button 
                        onClick={() => setFilterFilmMode('All')}
                        className="text-[10px] font-black text-blue-500 uppercase tracking-widest hover:underline"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                  
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Search simulation..."
                      className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:border-blue-500/50 transition-all"
                      value={filterFilmMode === 'All' ? '' : filterFilmMode}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (!val) setFilterFilmMode('All');
                        else {
                          const found = FILM_MODES.find(m => m.toLowerCase().includes(val.toLowerCase()));
                          if (found) setFilterFilmMode(found);
                          else setFilterFilmMode(val);
                        }
                      }}
                    />
                  </div>

                  <div className="max-h-32 overflow-y-auto pr-2 custom-scrollbar">
                    <div className="flex flex-wrap gap-2">
                      {['All', ...FILM_MODES].map(mode => (
                        <button 
                          key={mode}
                          onClick={() => setFilterFilmMode(mode)}
                          className={cn(
                            "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border flex items-center gap-1.5",
                            filterFilmMode === mode 
                              ? "bg-blue-500 border-blue-500 text-white shadow-lg shadow-blue-500/20" 
                              : "bg-slate-500/5 border-[var(--border-color)] text-slate-400 hover:border-blue-500/30"
                          )}
                        >
                          {mode === 'All' ? 'All' : (FILM_SHORT_CODES[mode] || mode)}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="space-y-3 col-span-1 md:col-span-2 lg:col-span-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tags</label>
                    {selectedTags.length > 0 && (
                      <button 
                        onClick={() => setSelectedTags([])}
                        className="text-[10px] font-black text-blue-500 uppercase tracking-widest hover:underline"
                      >
                        Clear ({selectedTags.length})
                      </button>
                    )}
                  </div>
                  
                  {/* Selected Tags Badges */}
                  {selectedTags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {selectedTags.map(tagName => {
                        const tag = tags.find(t => t.name === tagName);
                        return (
                          <button 
                            key={tagName}
                            onClick={() => setSelectedTags(prev => prev.filter(t => t !== tagName))}
                            className="px-2 py-0.5 bg-blue-500 text-white rounded-md text-[9px] font-black uppercase tracking-widest flex items-center gap-1 hover:bg-blue-600 transition-colors"
                          >
                            {tagName}
                            <X className="w-2.5 h-2.5" />
                          </button>
                        );
                      })}
                    </div>
                  )}

                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Search tags..."
                      className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:border-blue-500/50 transition-all"
                      value={tagSearchQuery}
                      onChange={(e) => setTagSearchQuery(e.target.value)}
                    />
                  </div>

                  <div className="max-h-32 overflow-y-auto pr-2 custom-scrollbar">
                    <div className="flex flex-wrap gap-2">
                      {tags
                        .filter(tag => 
                          tag.name.toLowerCase().includes(tagSearchQuery.toLowerCase()) && 
                          !selectedTags.includes(tag.name)
                        )
                        .map(tag => (
                          <button 
                            key={tag.id}
                            onClick={() => {
                              setSelectedTags(prev => [...prev, tag.name]);
                            }}
                            className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border flex items-center gap-1.5 bg-slate-500/5 border-[var(--border-color)] text-slate-400 hover:border-blue-500/30"
                          >
                            <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: tag.color }} />
                            {tag.name}
                          </button>
                        ))}
                      {tags.filter(tag => tag.name.toLowerCase().includes(tagSearchQuery.toLowerCase())).length === 0 && (
                        <p className="text-[10px] text-slate-500 italic w-full text-center py-2">No tags found</p>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-end pb-1">
                  <button 
                    onClick={() => {
                      setFilterDate('');
                      setFilterFilmMode('All');
                      setSelectedTags([]);
                      setFilterExtension('All');
                    }}
                    className="px-6 py-2.5 bg-red-500 hover:bg-red-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-red-500/20 flex items-center gap-2"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Reset All Filters
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Content Area */}
        <div className={cn(
          "flex-1 p-8 min-h-0",
          activeView === 'recipes' ? "flex flex-col" : "overflow-y-auto"
        )}>
          <AnimatePresence mode="wait">
            {activeView === 'stats' ? (
              <StatsView key="stats" photos={photos} theme={theme} />
            ) : activeView === 'templates' ? (
              <ExportTemplates 
                key="templates" 
                theme={theme} 
                onTryTemplate={(templateId) => {
                  if (photos.length > 0) {
                    setExportPhoto(photos[0]);
                    setInitialExportTemplate(templateId);
                    setIsExportModalOpen(true);
                  }
                }}
              />
            ) : activeView === 'recipes' ? (
              <RecipeView key="recipes" recipes={recipes} photos={photos} user={user} theme={theme} onAddRecipe={handleAddRecipe} />
            ) : activeView === 'timeline' ? (
              <TimelineView 
                key="timeline" 
                photos={photos} 
                onPhotoClick={setSelectedPhoto} 
                onSearchDate={(date) => {
                  setFilterDate(date);
                  setActiveView('photos');
                  setIsAdvancedFilterOpen(true);
                }}
              />
            ) : activeView === 'tags' ? (
              <TagsView 
                key="tags" 
                tags={tags} 
                setTags={setTags} 
                photos={photos} 
                setPhotos={setPhotos}
                onTagClick={(tagName) => {
                  setSelectedTags([tagName]);
                  setActiveView('photos');
                }} 
              />
            ) : activeView === 'settings' ? (
              <SettingsView 
                key="settings" 
                theme={theme} 
                setTheme={setTheme} 
                folders={folders} 
                setFolders={setFolders}
                cloudSyncEnabled={cloudSyncEnabled}
                setCloudSyncEnabled={setCloudSyncEnabled}
              />
            ) : (
              <div className="space-y-12">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <h2 className="text-4xl font-black tracking-tighter">
                      {activeFolderId 
                        ? folders.find(f => f.id === activeFolderId)?.name 
                        : activeView === 'photos' ? 'All Photos' : 
                          activeView === 'favorites' ? 'Favorites' : 'Photos'}
                    </h2>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">
                      {filteredPhotos.length} items in this view
                    </p>
                  </div>

                  {/* Top Sorting UI */}
                  <div className="flex items-center gap-3 bg-slate-500/5 p-2 rounded-2xl border border-[var(--border-color)] backdrop-blur-md">
                    <div className="flex items-center gap-2 px-3 border-r border-[var(--border-color)]">
                      <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sort</span>
                    </div>
                    <div className="flex gap-2">
                      {[
                        { label: 'Date', value: 'date' },
                        { label: 'Name', value: 'name' },
                        { label: 'Size', value: 'size' }
                      ].map(opt => (
                        <button
                          key={opt.value}
                          onClick={() => setSortBy(opt.value as any)}
                          className={cn(
                            "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                            sortBy === opt.value 
                              ? "bg-blue-500 text-white shadow-lg shadow-blue-500/20" 
                              : "text-slate-400 hover:text-slate-200 hover:bg-slate-500/10"
                          )}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                    <div className="w-px h-6 bg-[var(--border-color)] mx-1" />
                    <button 
                      onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                      className="p-2 hover:bg-slate-500/10 rounded-xl transition-all group"
                      title={sortOrder === 'asc' ? 'Ascending' : 'Descending'}
                    >
                      <ArrowUpDown className={cn("w-4 h-4 text-slate-400 group-hover:text-blue-500 transition-all", sortOrder === 'desc' && "rotate-180")} />
                    </button>
                  </div>
                </div>
                <VirtuosoGrid
                  data={filteredPhotos}
                  listClassName={cn(
                    "grid gap-8",
                    viewMode === 'grid' ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5" : "grid-cols-1"
                  )}
                  itemContent={(index, photo) => (
                    <PhotoCard 
                      key={photo.id} 
                      photo={photo} 
                      mode={viewMode} 
                      onClick={() => setSelectedPhoto(photo)} 
                      theme={theme}
                      onToggleFavorite={handleToggleFavorite}
                      onDeletePhoto={handleDeletePhoto}
                    />
                  )}
                />

                {filteredPhotos.length === 0 && (
                  <div className="col-span-full flex flex-col items-center justify-center py-32 text-slate-400 space-y-6">
                    <div className="w-20 h-20 bg-slate-500/5 rounded-full flex items-center justify-center">
                      <Images className="w-10 h-10 opacity-20" />
                    </div>
                    <p className="font-medium">No photos found matching your criteria.</p>
                  </div>
                )}
              </div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {selectedPhoto && (
          <PhotoDetailModal 
            photo={selectedPhoto} 
            onClose={() => setSelectedPhoto(null)} 
            recipes={recipes}
            folders={folders}
            onRecognize={handleRecognizeRecipe}
            theme={theme}
            allTags={tags}
            onExport={() => {
              setExportPhoto(selectedPhoto);
              setIsExportModalOpen(true);
            }}
            onUpdatePhoto={handleUpdatePhoto}
            onDeletePhoto={handleDeletePhoto}
            onAddTag={handleAddTag}
          />
        )}
        {isImportModalOpen && (
          <ImportModal 
            onClose={() => setIsImportModalOpen(false)} 
            user={user} 
            theme={theme}
            setFolders={setFolders}
            setPhotos={setPhotos}
            initialType={importModalInitialType}
            activeFolderId={activeFolderId}
            folders={folders}
          />
        )}
        {isSyncModalOpen && syncFolderId && (
        <SyncFolderModal 
          onClose={() => setIsSyncModalOpen(false)} 
          folderId={syncFolderId}
          folders={folders}
          setPhotos={setPhotos}
          user={user}
        />
      )}

      {isExportModalOpen && exportPhoto && (
          <RecipeExportModal 
            photo={exportPhoto}
            onClose={() => setIsExportModalOpen(false)}
            theme={theme}
            initialTemplate={initialExportTemplate}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// --- Sub-components ---

function CustomSelect({ 
  value, 
  onChange, 
  options, 
  placeholder, 
  className 
}: { 
  value: string, 
  onChange: (val: string) => void, 
  options: { label: string, value: string }[], 
  placeholder?: string,
  className?: string
}) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const selectedOption = options.find(opt => opt.value === value);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={cn("relative z-[60]", className)} ref={containerRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "w-full flex items-center justify-between bg-slate-500/5 backdrop-blur-xl border border-[var(--border-color)] rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-bold transition-all hover:bg-slate-500/10 text-sm",
          isOpen && "ring-2 ring-blue-500/50 border-blue-500/30"
        )}
      >
        <span className={cn("truncate", !selectedOption && "text-slate-500")}>
          {selectedOption ? selectedOption.label : placeholder}
        </span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          className="text-slate-400"
        >
          <ChevronDown className="w-4 h-4" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="absolute top-full left-0 right-0 mt-3 p-2 bg-[var(--bg-primary)]/90 backdrop-blur-2xl border border-[var(--border-color)] rounded-2xl shadow-2xl overflow-hidden z-[70]"
          >
            <div className="max-h-64 overflow-y-auto custom-scrollbar">
              {options.length === 0 ? (
                <div className="px-4 py-3 text-xs font-bold text-slate-500 uppercase tracking-widest text-center">
                  No options available
                </div>
              ) : (
                options.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => {
                      onChange(opt.value);
                      setIsOpen(false);
                    }}
                    className={cn(
                      "w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-bold transition-all text-left",
                      opt.value === value 
                        ? "bg-blue-500 text-white shadow-lg shadow-blue-500/20" 
                        : "hover:bg-slate-500/10 text-slate-400 hover:text-white"
                    )}
                  >
                    <span className="truncate">{opt.label}</span>
                    {opt.value === value && <Check className="w-4 h-4" />}
                  </button>
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Slider({ 
  value, 
  onChange, 
  min = -4, 
  max = 4, 
  step = 1,
  label
}: { 
  value: number, 
  onChange: (val: number) => void, 
  min?: number, 
  max?: number, 
  step?: number,
  label?: string
}) {
  return (
    <div className="space-y-4 p-6 bg-slate-500/5 rounded-2xl border border-[var(--border-color)]">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</span>
        <span className={cn(
          "text-sm font-black px-3 py-1 rounded-lg",
          value > 0 ? "bg-blue-500/10 text-blue-500" : value < 0 ? "bg-red-500/10 text-red-500" : "bg-slate-500/10 text-slate-500"
        )}>
          {value > 0 ? `+${value}` : value}
        </span>
      </div>
      <input 
        type="range" 
        min={min} 
        max={max} 
        step={step} 
        value={value} 
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-1.5 bg-slate-500/10 rounded-full appearance-none cursor-pointer accent-blue-500"
      />
      <div className="flex justify-between text-[8px] font-bold text-slate-500 uppercase tracking-tighter">
        <span>{min}</span>
        <span>0</span>
        <span>{max}</span>
      </div>
    </div>
  );
}

function Switch({ 
  checked, 
  onChange, 
  label 
}: { 
  checked: boolean, 
  onChange: (val: boolean) => void, 
  label: string 
}) {
  return (
    <div className="flex items-center justify-between p-6 bg-slate-500/5 rounded-2xl border border-[var(--border-color)]">
      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</span>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={cn(
          "relative w-12 h-6 rounded-full transition-colors duration-200 focus:outline-none",
          checked ? "bg-blue-500" : "bg-slate-500/20"
        )}
      >
        <motion.div
          animate={{ x: checked ? 26 : 4 }}
          className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm"
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
        />
      </button>
    </div>
  );
}

function CustomDatePicker({ 
  value, 
  onChange, 
  className 
}: { 
  value: string, 
  onChange: (val: string) => void, 
  className?: string
}) {
  return (
    <div className={cn("relative group", className)}>
      <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 group-focus-within:text-blue-500 transition-colors z-10">
        <Calendar className="w-4 h-4" />
      </div>
      <input 
        type="date" 
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-slate-500/5 backdrop-blur-xl border border-[var(--border-color)] rounded-2xl pl-12 pr-6 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-bold cursor-pointer hover:bg-slate-500/10 transition-all dark:color-scheme-dark text-sm dark:text-white"
      />
    </div>
  );
}

function DirectoryTree({ folders, onRefresh, photos, activeFolderId, onFolderSelect, onRename, onAddSubfolder, onAddFiles, onReorder, onUpdatePhoto }: { 
  folders: Folder[], 
  onRefresh: (id: string) => void, 
  photos: Photo[], 
  activeFolderId: string | null, 
  onFolderSelect: (id: string | null) => void,
  onRename: (id: string) => void,
  onAddSubfolder: (id: string) => void,
  onAddFiles: (id: string) => void,
  onReorder: (draggedId: string, targetId: string) => void,
  onUpdatePhoto: (id: string, updates: Partial<Photo>) => void
}) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set(['1']));
  const [dragOverId, setDragOverId] = useState<string | null>(null);
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, folderId: string } | null>(null);

  const toggle = (id: string) => {
    const next = new Set(expanded);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setExpanded(next);
  };

  const handleDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    setDragOverId(id);
  };

  const handleDragLeave = () => {
    setDragOverId(null);
  };

  const handleDrop = async (e: React.DragEvent, folderId: string) => {
    e.preventDefault();
    setDragOverId(null);
    const photoId = e.dataTransfer.getData('photoId');
    const draggedFolderId = e.dataTransfer.getData('folderId');

    if (photoId) {
      onUpdatePhoto(photoId, { folderId: folderId });
    } else if (draggedFolderId && draggedFolderId !== folderId) {
      onReorder(draggedFolderId, folderId);
    }
  };

  const handleContextMenu = (e: React.MouseEvent, folderId: string) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY, folderId });
  };

  const handleFolderDragStart = (e: React.DragEvent, folderId: string) => {
    e.dataTransfer.setData('folderId', folderId);
  };

  return (
    <div className="space-y-1 relative" onClick={() => setContextMenu(null)}>
      {folders.map(node => {
        const photoCount = photos.filter(p => p.folderId === node.id).length;
        const isActive = activeFolderId === node.id;
        return (
          <div 
            key={node.id} 
            className="space-y-1"
            draggable
            onDragStart={(e) => handleFolderDragStart(e, node.id)}
            onDragOver={(e) => handleDragOver(e, node.id)}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, node.id)}
            onContextMenu={(e) => handleContextMenu(e, node.id)}
          >
            <div className={cn(
              "flex items-center group rounded-xl transition-all",
              dragOverId === node.id ? "bg-blue-500/20 scale-[1.02]" : "hover:bg-slate-500/5",
              isActive && "bg-blue-500/10"
            )}>
              <button 
                onClick={() => toggle(node.id)}
                className="p-1.5 hover:bg-slate-500/10 rounded-md transition-colors"
              >
                <ChevronDown className={cn("w-3.5 h-3.5 text-slate-400 transition-transform", !expanded.has(node.id) && "-rotate-90")} />
              </button>
              <button 
                onClick={() => onFolderSelect(isActive ? null : node.id)}
                className={cn(
                  "flex-1 px-2 py-2 rounded-lg flex items-center gap-3 text-xs font-bold transition-all truncate",
                  isActive ? "text-blue-500" : "text-slate-400 hover:text-blue-500"
                )}
              >
                {node.type === 'physical' ? (
                  <HardDrive className={cn("w-4 h-4 transition-colors", (dragOverId === node.id || isActive) ? "text-blue-500" : "opacity-50")} />
                ) : (
                  <FolderIcon className={cn("w-4 h-4 transition-colors", (dragOverId === node.id || isActive) ? "text-blue-500" : "opacity-50")} />
                )}
                <span className="truncate flex-1 text-left">{node.name}</span>
                <span className="text-[10px] opacity-40 font-black bg-slate-500/10 px-2 py-0.5 rounded-full">{photoCount || node.photoCount}</span>
              </button>
              {node.type === 'physical' && (
                <div className="flex items-center opacity-0 group-hover:opacity-100 transition-all">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      // Logic to open original directory
                      console.log('Opening original directory:', node.path);
                    }}
                    className="p-2 hover:bg-blue-500/10 rounded-md transition-all text-blue-500"
                    title="Open original directory"
                  >
                    <Plane className="w-3.5 h-3.5" />
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onRefresh(node.id);
                    }}
                    className="p-2 hover:bg-blue-500/10 rounded-md transition-all text-blue-500"
                    title="Refresh folder"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>
        );
      })}

      {/* Context Menu */}
      <AnimatePresence>
        {contextMenu && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            style={{ left: contextMenu.x, top: contextMenu.y }}
            className="fixed z-[100] w-48 glass-card rounded-2xl shadow-2xl border border-[var(--border-color)] overflow-hidden p-1.5"
          >
            <ContextMenuItem icon={<Edit2 className="w-3.5 h-3.5" />} label="Rename" onClick={() => onRename(contextMenu.folderId)} />
            <ContextMenuItem icon={<Plus className="w-3.5 h-3.5" />} label="Add Photos" onClick={() => onAddFiles(contextMenu.folderId)} />
            <ContextMenuItem icon={<FolderPlus className="w-3.5 h-3.5" />} label="New Subfolder" onClick={() => onAddSubfolder(contextMenu.folderId)} />
            <div className="h-px bg-[var(--border-color)] my-1.5 mx-2" />
            <ContextMenuItem icon={<Trash2 className="w-3.5 h-3.5 text-red-500" />} label="Delete" onClick={() => {}} danger />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ContextMenuItem({ icon, label, onClick, danger }: { icon: React.ReactNode, label: string, onClick: () => void, danger?: boolean }) {
  return (
    <button 
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      className={cn(
        "w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-bold transition-all",
        danger ? "text-red-500 hover:bg-red-500/10" : "text-slate-400 hover:bg-slate-500/10 hover:text-slate-600 dark:hover:text-white"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function NavItem({ icon, label, active, onClick, theme }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void, theme: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all group",
        active 
          ? "bg-blue-500 text-white shadow-lg shadow-blue-500/20" 
          : "text-slate-400 hover:bg-blue-500/5 hover:text-blue-500"
      )}
    >
      <span className={cn("transition-colors", active ? "text-white" : "text-slate-500 group-hover:text-blue-500")}>
        {icon}
      </span>
      {label}
    </button>
  );
}

const PhotoCard = React.memo(({ photo, mode, onClick, theme, onToggleFavorite, onDeletePhoto }: { photo: Photo, mode: 'grid' | 'list', onClick: () => void, theme: string, onToggleFavorite: (id: string) => void, onDeletePhoto: (id: string) => void }) => {
  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('photoId', photo.id);
  };

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(photo.id);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this photo?')) {
      onDeletePhoto(photo.id);
    }
  };

  if (mode === 'list') {
    return (
      <div 
        draggable
        onDragStart={handleDragStart}
        className="group"
      >
        <motion.div 
          layout
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={onClick}
          className="flex items-center gap-6 p-4 glass-card rounded-2xl cursor-pointer"
        >
          <img src={photo.thumbnailUrl} className="w-20 h-20 object-cover rounded-xl shadow-sm" alt={photo.fileName} loading="lazy" />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3">
              <h3 className="font-bold text-lg truncate">{photo.fileName}</h3>
              {photo.fileName.toLowerCase().endsWith('.raf') && (
                <span className="px-1.5 py-0.5 bg-orange-500 text-white text-[8px] font-black uppercase tracking-widest rounded-md">RAW</span>
              )}
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-400 mt-2">
              <span className="flex items-center gap-1.5 bg-blue-500/10 text-blue-500 px-2 py-1 rounded-md"><Camera className="w-3.5 h-3.5" /> {photo.cameraModel}</span>
              <span className="px-2 py-1 bg-slate-500/10 text-slate-600 dark:text-slate-300 rounded-md font-black text-[10px] uppercase tracking-widest">
                {FILM_SHORT_CODES[photo.filmMode || ''] || '??'}
              </span>
              <span>{new Date(photo.dateTime || '').toLocaleDateString()}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={handleToggleFavorite} className="p-2 hover:bg-red-500/10 rounded-xl transition-all">
              <Heart className={cn("w-5 h-5 transition-all", photo.isFavorite ? "text-red-500 fill-red-500" : "text-slate-300")} />
            </button>
            <button onClick={handleDelete} className="p-2 hover:bg-red-500/10 rounded-xl transition-all">
              <Trash2 className="w-5 h-5 text-slate-300 hover:text-red-500 transition-all" />
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div 
      draggable
      onDragStart={handleDragStart}
      className="group"
    >
      <motion.div 
        layout
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        whileHover={{ y: -8, scale: 1.02 }}
        onClick={onClick}
        className="relative glass-card rounded-3xl overflow-hidden cursor-pointer"
      >
        <div className="aspect-video overflow-hidden relative">
          <img 
            src={photo.thumbnailUrl} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
            alt={photo.fileName} 
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
            <p className="text-sm font-bold truncate text-white">{photo.fileName}</p>
            <p className="text-xs text-slate-300 mt-1">{photo.cameraModel}</p>
          </div>
          <div className="absolute top-4 left-4 px-2 py-1 bg-black/40 backdrop-blur-md rounded-lg border border-white/10 flex items-center gap-2">
            <span className="text-[10px] font-black text-white uppercase tracking-widest">
              {FILM_SHORT_CODES[photo.filmMode || ''] || '??'}
            </span>
            {photo.fileName.toLowerCase().endsWith('.raf') && (
              <span className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse" title="RAW File" />
            )}
          </div>
          <button 
            onClick={handleToggleFavorite}
            className="absolute top-4 right-4 p-2 bg-white/20 backdrop-blur-xl rounded-2xl border border-white/30 hover:bg-white/40 transition-all"
          >
            <Heart className={cn("w-4 h-4 transition-all", photo.isFavorite ? "text-red-500 fill-red-500" : "text-white")} />
          </button>
        </div>
        <div className="p-5 flex items-center justify-between gap-4">
          <div className="flex flex-wrap gap-1.5 flex-1 min-w-0">
            {photo.tags?.slice(0, 2).map(tag => (
              <span key={tag} className="px-2 py-0.5 bg-blue-500/10 text-blue-500 rounded-md text-[8px] font-black uppercase tracking-widest border border-blue-500/20">
                {tag}
              </span>
            ))}
            {photo.tags && photo.tags.length > 2 && (
              <span className="text-[8px] font-black text-slate-400">+{photo.tags.length - 2}</span>
            )}
            {!photo.tags?.length && (
              <span className="text-[10px] font-black uppercase tracking-widest text-blue-500 truncate">{photo.filmMode || 'Unknown'}</span>
            )}
          </div>
          <button 
            onClick={handleDelete}
            className="p-2 hover:bg-red-500/10 rounded-xl transition-all group/delete"
          >
            <Trash2 className="w-4 h-4 text-slate-300 group-hover/delete:text-red-500 transition-all" />
          </button>
        </div>
      </motion.div>
    </div>
  );
});

function PhotoDetailModal({ photo, onClose, recipes, folders, onRecognize, theme, allTags, onExport, onUpdatePhoto, onDeletePhoto, onAddTag }: { photo: Photo, onClose: () => void, recipes: Recipe[], folders: Folder[], onRecognize: (p: Photo) => void, theme: string, allTags: Tag[], onExport: () => void, onUpdatePhoto: (id: string, updates: Partial<Photo>) => void, onDeletePhoto: (id: string) => void, onAddTag: (tag: Tag) => void }) {
  const [isFavorite, setIsFavorite] = useState(photo.isFavorite);
  const [isHidden, setIsHidden] = useState(photo.isHidden);
  const [rating, setRating] = useState(photo.rating);
  const [photoTags, setPhotoTags] = useState<string[]>(photo.tags || []);
  const [newTag, setNewTag] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedRecipeId, setSelectedRecipeId] = useState(photo.recipeId || '');

  const suggestions = allTags
    .filter(t => t.name.toLowerCase().includes(newTag.toLowerCase()))
    .filter(t => !photoTags.includes(t.name))
    .slice(0, 5);

  const folder = folders.find(f => f.id === photo.folderId);
  const currentRecipe = recipes.find(r => r.id === selectedRecipeId);

  // Parse WB Shift
  const wbShift = photo.whiteBalanceShift?.split(',').map(s => s.trim()) || [];
  const wbRed = wbShift[0] || '0';
  const wbBlue = wbShift[1] || '0';

  // Parse Grain Effect
  const grainParts = photo.grainEffect?.split(',').map(s => s.trim()) || [];
  const grainRoughness = grainParts[0] || 'Off';
  const grainSize = grainParts[1] || 'Off';

  const handleToggleFavorite = async () => {
    const newVal = !isFavorite;
    setIsFavorite(newVal);
    onUpdatePhoto(photo.id, { isFavorite: newVal });
  };

  const handleToggleHidden = async () => {
    const newVal = !isHidden;
    setIsHidden(newVal);
    onUpdatePhoto(photo.id, { isHidden: newVal });
    if (newVal) onClose();
  };

  const handleRating = async (r: number) => {
    setRating(r);
    onUpdatePhoto(photo.id, { rating: r });
  };

  const handleAddTag = async (tagName: string) => {
    const cleanTag = tagName.trim();
    if (!cleanTag || photoTags.includes(cleanTag)) return;
    const updatedTags = [...photoTags, cleanTag];
    setPhotoTags(updatedTags);
    setNewTag('');
    onUpdatePhoto(photo.id, { tags: updatedTags });
    
    if (!allTags.some(t => t.name === cleanTag)) {
      onAddTag({
        id: `t-${Date.now()}`,
        name: cleanTag,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        ownerId: photo.ownerId
      });
    }
  };

  const handleRemoveTag = async (tagToRemove: string) => {
    const updatedTags = photoTags.filter(t => t !== tagToRemove);
    setPhotoTags(updatedTags);
    onUpdatePhoto(photo.id, { tags: updatedTags });
  };

  const handleRecipeChange = (recipeId: string) => {
    setSelectedRecipeId(recipeId);
    onUpdatePhoto(photo.id, { recipeId });
  };

  const handleDelete = async () => {
    onDeletePhoto(photo.id);
    onClose();
  };

  return (
    <>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-10 bg-black/60 backdrop-blur-xl"
        onClick={onClose}
      >
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="glass w-full max-w-6xl h-full max-h-[90vh] rounded-[2.5rem] overflow-hidden flex flex-col lg:flex-row shadow-2xl"
          onClick={e => e.stopPropagation()}
        >
          {/* Image Preview */}
          <div className="flex-1 bg-black/20 flex items-center justify-center relative group">
            <img src={photo.thumbnailUrl} className="max-w-full max-h-full object-contain" alt={photo.fileName} />
            {photo.fileName.toLowerCase().endsWith('.raf') && (
              <div className="absolute top-8 right-8 px-4 py-2 bg-orange-500 text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg">
                RAW / RAF
              </div>
            )}
            <button 
              onClick={onClose}
              className="absolute top-8 left-8 p-3 bg-white/10 hover:bg-white/20 backdrop-blur-xl rounded-2xl transition-all border border-white/20 text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Info Panel */}
          <div className="w-full lg:w-[28rem] flex flex-col bg-[var(--bg-primary)]/50 backdrop-blur-2xl border-l border-[var(--border-color)]">
            <div className="p-6 border-b border-[var(--border-color)] flex items-center justify-between gap-4">
              <div className="min-w-0">
                <h2 className="text-xl font-black tracking-tight truncate">{photo.fileName}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{new Date(photo.dateTime || '').toLocaleString()}</p>
                  <span className="text-slate-600">•</span>
                  <div className="flex items-center gap-1 text-[10px] font-bold text-blue-500 uppercase tracking-widest">
                    <HardDrive className="w-3 h-3" />
                    {folder?.name || 'Uncategorized'}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={onExport}
                  className="p-2.5 bg-slate-500/5 hover:bg-orange-500/10 text-slate-400 hover:text-orange-500 rounded-xl transition-all border border-transparent hover:border-orange-500/20"
                  title="Export Recipe"
                >
                  <Share2 className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setShowDeleteConfirm(true)}
                  className="p-2.5 bg-slate-500/5 hover:bg-red-500/10 text-slate-400 hover:text-red-500 rounded-xl transition-all border border-transparent hover:border-red-500/20"
                  title="Delete Photo"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-8">
              {/* Quick Actions */}
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-1 bg-slate-500/5 p-1.5 rounded-xl border border-[var(--border-color)]">
                  {[1, 2, 3, 4, 5].map(r => (
                    <button key={r} onClick={() => handleRating(r)} className="p-1">
                      <Star className={cn("w-4 h-4 transition-all", r <= rating ? "text-yellow-500 fill-yellow-500" : "text-slate-300 hover:text-yellow-500/50")} />
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={handleToggleFavorite}
                    className={cn("p-2 rounded-lg transition-all border", isFavorite ? "bg-red-500/10 text-red-500 border-red-500/20" : "bg-white/5 text-slate-400 border-transparent hover:text-red-500")}
                  >
                    <Heart className={cn("w-4 h-4", isFavorite && "fill-red-500")} />
                  </button>
                </div>
              </div>

              {/* Film Recipe Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Associated Recipe</h3>
                  {currentRecipe && (
                    <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest bg-blue-500/10 px-2 py-0.5 rounded-full">Active</span>
                  )}
                </div>
                <div className="space-y-3">
                  <CustomSelect 
                    value={selectedRecipeId}
                    onChange={handleRecipeChange}
                    placeholder="Select a recipe..."
                    options={recipes.map(r => ({ label: r.name, value: r.id }))}
                    className="!rounded-xl"
                  />
                  {currentRecipe && (
                    <div className="p-4 bg-slate-500/5 rounded-2xl border border-[var(--border-color)] flex items-center gap-4">
                      <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500">
                        <FlaskConical className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-black truncate">{currentRecipe.name}</p>
                        <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{currentRecipe.filmMode}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* AI Recognition Button */}
              <button 
                onClick={() => onRecognize(photo)}
                className="w-full py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                <Sparkles className="w-4 h-4" />
                AI Smart Recognition
              </button>

              {/* Parameters Section */}
              <div className="space-y-8">
                {/* EXIF Metadata */}
                <div className="space-y-4">
                  <h3 className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">EXIF Metadata</h3>
                  <div className="grid grid-cols-3 gap-2">
                    <CompactExif icon={<Camera className="w-3 h-3" />} value={photo.cameraModel} />
                    <CompactExif icon={<ArrowUpDown className="w-3 h-3" />} value={photo.fNumber} />
                    <CompactExif icon={<Clock className="w-3 h-3" />} value={photo.exposureTime} />
                    <CompactExif icon={<LayoutGrid className="w-3 h-3" />} value={photo.iso?.toString()} />
                    <CompactExif icon={<ArrowUpDown className="w-3 h-3" />} value={photo.focalLength} />
                    <CompactExif icon={<Info className="w-3 h-3" />} value={photo.lensModel} />
                  </div>
                </div>

                {/* Film Settings */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Film Settings</h3>
                    <div className="px-3 py-1 bg-blue-500/10 text-blue-500 rounded-full text-[8px] font-black uppercase tracking-widest border border-blue-500/20">
                      {photo.filmMode || 'Provia'}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <FilmSettingCard label="White Balance" value={photo.whiteBalance} />
                    <FilmSettingCard label="Dynamic Range" value={photo.dynamicRange} />
                    <FilmSettingCard label="Highlight" value={photo.highlightTone} />
                    <FilmSettingCard label="Shadow" value={photo.shadowTone} />
                    <FilmSettingCard label="Color" value={photo.saturation} />
                    <FilmSettingCard label="Sharpness" value={photo.sharpness} />
                    <FilmSettingCard label="Noise Reduction" value={photo.noiseReduction} />
                    <FilmSettingCard label="Clarity" value={photo.clarity} />
                    <FilmSettingCard label="Grain Roughness" value={grainRoughness} />
                    <FilmSettingCard label="Grain Size" value={grainSize} />
                    <FilmSettingCard label="Color Chrome" value={photo.colorChromeEffect} />
                    <FilmSettingCard label="FX Blue" value={photo.colorChromeEffectBlue} />
                    <FilmSettingCard label="WB Red" value={wbRed} />
                    <FilmSettingCard label="WB Blue" value={wbBlue} />
                  </div>
                </div>
              </div>

              {/* Tags Section */}
              <div className="space-y-4 pt-6 border-t border-[var(--border-color)]">
                <h3 className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Tags</h3>
                <div className="flex flex-wrap gap-1.5">
                  {photoTags.map(tag => (
                    <span 
                      key={tag} 
                      className="flex items-center gap-1.5 px-2 py-1 bg-blue-500/10 text-blue-500 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-500/20 group/tag"
                    >
                      {tag}
                      <button onClick={() => handleRemoveTag(tag)} className="hover:text-red-500 transition-colors">
                        <X className="w-2.5 h-2.5" />
                      </button>
                    </span>
                  ))}
                  <div className="relative">
                    <input 
                      type="text"
                      placeholder="+"
                      className="w-12 bg-slate-500/5 border border-[var(--border-color)] rounded-lg px-2 py-1 text-[9px] font-bold focus:outline-none focus:w-24 transition-all"
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleAddTag(newTag)}
                    />
                    {newTag && suggestions.length > 0 && (
                      <div className="absolute bottom-full mb-2 left-0 w-48 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-xl shadow-2xl overflow-hidden z-10">
                        {suggestions.map(tag => (
                          <button
                            key={tag.id}
                            onClick={() => handleAddTag(tag.name)}
                            className="w-full px-4 py-2 text-left text-[10px] font-bold hover:bg-blue-500/10 hover:text-blue-500 transition-colors flex items-center gap-2"
                          >
                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: tag.color }} />
                            {tag.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                {!newTag && allTags.length > 0 && allTags.some(t => !photoTags.includes(t.name)) && (
                  <div className="flex flex-wrap gap-1.5 pt-2">
                    <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest w-full mb-1">Available Tags</span>
                    {allTags.filter(t => !photoTags.includes(t.name)).slice(0, 10).map(tag => (
                      <button
                        key={tag.id}
                        onClick={() => handleAddTag(tag.name)}
                        className="px-2 py-1 bg-slate-500/5 hover:bg-slate-500/10 text-slate-400 hover:text-blue-500 rounded-lg text-[8px] font-black uppercase tracking-widest border border-transparent hover:border-blue-500/20 transition-all"
                      >
                        {tag.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="p-8 border-t border-[var(--border-color)] flex flex-col gap-4">
              <div className="flex gap-4">
                <button 
                  onClick={() => console.log('Locating file:', photo.filePath)}
                  className="flex-1 py-4 bg-slate-500/5 hover:bg-slate-500/10 rounded-2xl text-sm font-black transition-all flex items-center justify-center gap-3 border border-[var(--border-color)]"
                >
                  <Navigation className="w-5 h-5" />
                  Locate File
                </button>
                <button 
                  onClick={() => console.log('Opening original:', photo.filePath)}
                  className="flex-1 py-4 bg-slate-500/5 hover:bg-slate-500/10 rounded-2xl text-sm font-black transition-all flex items-center justify-center gap-3 border border-[var(--border-color)]"
                >
                  <ExternalLink className="w-5 h-5" />
                  Original
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <AnimatePresence>
        {showDeleteConfirm && (
          <ConfirmModal 
            title="Delete Photo"
            message={`Are you sure you want to delete "${photo.fileName}"? This action cannot be undone.`}
            confirmLabel="Delete"
            onConfirm={handleDelete}
            onCancel={() => setShowDeleteConfirm(false)}
            variant="danger"
          />
        )}
      </AnimatePresence>
    </>
  );
}

function ConfirmModal({ title, message, confirmLabel, onConfirm, onCancel, variant = 'primary' }: { title: string, message: string, confirmLabel: string, onConfirm: () => void, onCancel: () => void, variant?: 'primary' | 'danger' }) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl" onClick={onCancel}>
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="glass w-full max-w-md rounded-[2.5rem] overflow-hidden shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-8 border-b border-[var(--border-color)] flex items-center justify-between">
          <h2 className="text-xl font-black tracking-tight">{title}</h2>
          <button onClick={onCancel} className="p-2 hover:bg-slate-500/10 rounded-2xl transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-10 space-y-8">
          <p className="text-sm font-bold text-slate-400 leading-relaxed">{message}</p>
          <div className="flex gap-4">
            <button 
              onClick={onCancel}
              className="flex-1 py-4 bg-slate-500/5 hover:bg-slate-500/10 rounded-2xl text-sm font-black transition-all border border-[var(--border-color)]"
            >
              Cancel
            </button>
            <button 
              onClick={onConfirm}
              className={cn(
                "flex-1 py-4 text-white rounded-2xl text-sm font-black transition-all shadow-lg",
                variant === 'danger' ? "bg-red-500 hover:bg-red-600 shadow-red-500/20" : "bg-blue-500 hover:bg-blue-600 shadow-blue-500/20"
              )}
            >
              {confirmLabel}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function CompactExif({ icon, value }: { icon: React.ReactNode, value?: string }) {
  return (
    <div className="bg-slate-500/5 p-2 rounded-xl border border-[var(--border-color)] flex items-center gap-2 min-w-0">
      <div className="text-slate-400 flex-shrink-0">{icon}</div>
      <p className="text-[10px] font-black truncate">{value || '-'}</p>
    </div>
  );
}

function ExifItem({ icon, label, value }: { icon: React.ReactNode, label: string, value?: string }) {
  return (
    <div className="bg-slate-500/5 p-4 rounded-2xl border border-[var(--border-color)] space-y-2">
      <div className="flex items-center gap-2 text-slate-400">
        {icon}
        <span className="text-[10px] font-bold uppercase tracking-widest">{label}</span>
      </div>
      <p className="text-sm font-black truncate">{value || 'N/A'}</p>
    </div>
  );
}

function FilmSettingCard({ label, value }: { label: string, value?: string }) {
  return (
    <div className="bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl flex flex-col gap-1 shadow-sm">
      <span className="text-[8px] font-black uppercase tracking-[0.15em] text-slate-400">{label}</span>
      <span className="text-sm font-black text-slate-900 dark:text-white">{value || '0'}</span>
    </div>
  );
}

function FilmTag({ label, value, primary }: { label: string, value?: string, primary?: boolean }) {
  return (
    <div className={cn(
      "flex items-center justify-between px-4 py-2.5 rounded-xl text-[10px] font-black border transition-all",
      primary 
        ? "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20" 
        : "bg-slate-500/5 text-slate-500 border-[var(--border-color)]"
    )}>
      <span className="uppercase tracking-widest opacity-60">{label}</span>
      <span className="uppercase tracking-widest">{value || '0'}</span>
    </div>
  );
}

function ImportModal({ onClose, user, theme, setFolders, setPhotos, initialType, activeFolderId, folders }: { onClose: () => void, user: User | null, theme: string, setFolders: React.Dispatch<React.SetStateAction<Folder[]>>, setPhotos: React.Dispatch<React.SetStateAction<Photo[]>>, initialType: 'files' | 'folders', activeFolderId: string | null, folders: Folder[] }) {
  const [files, setFiles] = useState<File[]>([]);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [folderName, setFolderName] = useState('');
  const [folderPath, setFolderPath] = useState('');
  const [selectedDestFolderId, setSelectedDestFolderId] = useState<string | null>(activeFolderId);
  const [includeSubfolders, setIncludeSubfolders] = useState(true);
  const [importMode, setImportMode] = useState<'create' | 'import'>(initialType === 'folders' ? 'create' : 'import');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    if (selectedFiles.length > 0) {
      setFiles(selectedFiles);
    }
  };

  const handleFolderSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    if (selectedFiles.length > 0) {
      setFiles(selectedFiles);
      // Automatically set folder name from the first file's path if available
      const firstFile = selectedFiles[0] as any;
      if (firstFile.webkitRelativePath) {
        const pathParts = firstFile.webkitRelativePath.split('/');
        if (pathParts.length > 1) {
          setFolderName(pathParts[0]);
        }
      }
    }
  };

  const handleImport = async () => {
    if (importMode === 'import' && files.length === 0) return;
    if (importMode === 'create' && !folderName) return;

    setImporting(true);
    setProgress(0);

    let targetFolderId = selectedDestFolderId;

    // If it's a folder import or creation, create the folder first
    if (folderName) {
      const newFolderId = `f-${Date.now()}`;
      targetFolderId = newFolderId;

      setFolders(prev => [...prev, { 
        id: newFolderId, 
        name: folderName, 
        parentId: selectedDestFolderId || undefined,
        path: folderPath || 'Local Import', 
        type: folderPath ? 'physical' : 'logical',
        includeSubfolders, 
        photoCount: files.length,
        lastSynced: new Date().toISOString()
      }]);
    }

    if (importMode === 'create') {
      setImporting(false);
      onClose();
      return;
    }

    const newPhotos: Photo[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const metadata = await (exifr as any).parse(file, {
          tiff: true,
          xmp: true,
          icc: true,
          jfif: true,
          ihdr: true,
          fujifilm: true
        }).catch(() => ({}));
        
        // Extract thumbnail
        let thumbnailUrl = '';
        const isRaf = file.name.toLowerCase().endsWith('.raf');
        
        if (isRaf) {
          try {
            const thumb = await (exifr as any).thumbnail(file);
            if (thumb) {
              // Convert Uint8Array/Blob to base64 for storage (following existing pattern)
              const blob = new Blob([thumb], { type: 'image/jpeg' });
              thumbnailUrl = await new Promise<string>((resolve) => {
                const reader = new FileReader();
                reader.onload = (e) => resolve(e.target?.result as string);
                reader.readAsDataURL(blob);
              });
            }
          } catch (e) {
            console.warn('Could not extract thumbnail from RAF:', file.name, e);
          }
        }

        if (!thumbnailUrl) {
          // Fallback for JPG or if RAF thumbnail extraction failed
          const reader = new FileReader();
          thumbnailUrl = await new Promise<string>((resolve) => {
            reader.onload = (e) => resolve(e.target?.result as string);
            reader.readAsDataURL(file);
          });
        }

        const photoData: Photo = {
          id: `p-${Date.now()}-${i}`,
          fileName: file.name,
          filePath: file.name,
          thumbnailUrl: thumbnailUrl,
          cameraModel: metadata?.Model || 'Unknown Camera',
          lensModel: metadata?.LensModel || 'Unknown Lens',
          dateTime: metadata?.DateTimeOriginal?.toISOString() || new Date().toISOString(),
          exposureTime: metadata?.ExposureTime ? `1/${Math.round(1/metadata.ExposureTime)}` : 'N/A',
          fNumber: metadata?.FNumber ? `f/${metadata.FNumber}` : 'N/A',
          iso: metadata?.ISO || 0,
          focalLength: metadata?.FocalLength ? `${metadata.FocalLength}mm` : 'N/A',
          filmMode: metadata?.FilmMode || 'Provia/Standard',
          whiteBalance: metadata?.WhiteBalance || 'Auto',
          dynamicRange: metadata?.DynamicRange || '100%',
          sharpness: metadata?.Sharpness?.toString() || '0',
          saturation: metadata?.Saturation?.toString() || '0',
          contrast: metadata?.Contrast?.toString() || '0',
          clarity: metadata?.Clarity?.toString() || '0',
          shadowTone: metadata?.ShadowTone?.toString() || '0',
          highlightTone: metadata?.HighlightTone?.toString() || '0',
          noiseReduction: metadata?.NoiseReduction?.toString() || '0',
          grainEffect: metadata?.GrainEffect || 'Off',
          colorChromeEffect: metadata?.ColorChromeEffect || 'Off',
          colorChromeEffectBlue: metadata?.ColorChromeEffectBlue || 'Off',
          isFavorite: false,
          isHidden: false,
          rating: 0,
          tags: [],
          ownerId: user?.uid || 'demo',
          recipeId: '',
          folderId: targetFolderId || ''
        };

        newPhotos.push(photoData);
        setProgress(Math.round(((i + 1) / files.length) * 100));
      } catch (err) {
        console.error('Error importing file:', file.name, err);
      }
    }

    setPhotos(prev => [...prev, ...newPhotos]);
    setImporting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="glass w-full max-w-2xl rounded-[2.5rem] overflow-hidden shadow-2xl"
      >
        <div className="p-8 border-b border-[var(--border-color)] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center">
              {importMode === 'import' ? <Plus className="w-6 h-6 text-blue-500" /> : <FolderIcon className="w-6 h-6 text-blue-500" />}
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight">{importMode === 'import' ? 'Import System Folder' : 'Create Logical Folder'}</h2>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                {importMode === 'import' ? 'Select a directory to import JPG and RAF photos' : 'Add a new folder to your library structure'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-500/10 rounded-2xl transition-all">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-10 space-y-8">
          {initialType === 'folders' && (
            <div className="flex p-1 bg-slate-500/5 rounded-xl border border-[var(--border-color)]">
              <button 
                onClick={() => setImportMode('create')}
                className={cn(
                  "flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all",
                  importMode === 'create' ? "bg-blue-500 text-white shadow-lg shadow-blue-500/20" : "text-slate-400 hover:text-slate-200"
                )}
              >
                Create Only
              </button>
              <button 
                onClick={() => setImportMode('import')}
                className={cn(
                  "flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all",
                  importMode === 'import' ? "bg-blue-500 text-white shadow-lg shadow-blue-500/20" : "text-slate-400 hover:text-slate-200"
                )}
              >
                Import System
              </button>
            </div>
          )}

          {importMode === 'create' ? (
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Folder Name</label>
                <input 
                  type="text" 
                  className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-bold"
                  placeholder="e.g. My Fuji Photos"
                  value={folderName}
                  onChange={e => setFolderName(e.target.value)}
                />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Parent Folder</label>
                <CustomSelect 
                  value={selectedDestFolderId || ''}
                  onChange={(val) => setSelectedDestFolderId(val || null)}
                  placeholder="Root Library"
                  options={folders.map(f => ({ label: f.name, value: f.id }))}
                />
              </div>
              <button 
                onClick={handleImport}
                disabled={!folderName}
                className="w-full py-5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-2xl font-black shadow-lg shadow-blue-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3"
              >
                <Check className="w-5 h-5" />
                Create Folder
              </button>
            </div>
          ) : (
            <div className="space-y-8">
              <div 
                className={cn(
                  "border-4 border-dashed rounded-[2rem] p-12 flex flex-col items-center justify-center space-y-6 transition-all cursor-pointer",
                  files.length > 0 ? "border-blue-500/30 bg-blue-500/5" : "border-slate-500/10 hover:border-blue-500/30 hover:bg-blue-500/5"
                )}
                onClick={() => initialType === 'files' ? fileInputRef.current?.click() : folderInputRef.current?.click()}
              >
                <div className="w-20 h-20 bg-blue-500/10 rounded-full flex items-center justify-center">
                  {initialType === 'files' ? <Plus className="w-10 h-10 text-blue-500" /> : <FolderIcon className="w-10 h-10 text-blue-500" />}
                </div>
                <div className="text-center space-y-2">
                  <p className="font-black text-xl tracking-tight">
                    {files.length > 0 ? `${files.length} files selected` : `Click to select ${initialType === 'files' ? 'photos' : 'folder'}`}
                  </p>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                    {initialType === 'files' ? 'Supports JPG and RAF formats' : 'All photos in the folder will be imported'}
                  </p>
                </div>
                <input 
                  type="file" 
                  multiple 
                  accept=".jpg,.jpeg,.raf" 
                  className="hidden" 
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                />
                <input 
                  type="file" 
                  {...({ webkitdirectory: "", directory: "" } as any)}
                  className="hidden" 
                  ref={folderInputRef}
                  onChange={handleFolderSelect}
                />
              </div>

              {files.length > 0 && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between text-xs font-bold uppercase tracking-widest">
                    <span className="text-slate-400">{files.length} files ready to import</span>
                    <button onClick={() => setFiles([])} className="text-red-500 hover:text-red-600">Clear</button>
                  </div>
                  
                  {importing ? (
                    <div className="space-y-4">
                      <div className="h-3 bg-slate-500/10 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full bg-gradient-to-r from-blue-500 to-indigo-600"
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                        />
                      </div>
                      <p className="text-center text-xs font-bold text-slate-400 uppercase tracking-widest">Importing... {progress}%</p>
                    </div>
                  ) : (
                    <button 
                      onClick={handleImport}
                      className="w-full py-5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-2xl font-black shadow-lg shadow-blue-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                    >
                      Start Import
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function SyncFolderModal({ onClose, folderId, folders, setPhotos, user }: { onClose: () => void, folderId: string, folders: Folder[], setPhotos: React.Dispatch<React.SetStateAction<Photo[]>>, user: User | null }) {
  const folder = folders.find(f => f.id === folderId);
  const [scanning, setScanning] = useState(true);
  const [newFiles, setNewFiles] = useState<any[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());

  useEffect(() => {
    // Simulate scanning
    const timer = setTimeout(() => {
      const mockFiles = [
        { id: 'new-1', fileName: 'DSCF1234.RAF', date: '2024-04-03', filmMode: 'Classic Chrome', size: '24.5 MB' },
        { id: 'new-2', fileName: 'DSCF1235.JPG', date: '2024-04-03', filmMode: 'Velvia', size: '8.2 MB' },
        { id: 'new-3', fileName: 'DSCF1236.RAF', date: '2024-04-04', filmMode: 'Classic Neg', size: '25.1 MB' },
      ];
      setNewFiles(mockFiles);
      setSelectedFiles(new Set(mockFiles.map(f => f.id)));
      setScanning(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  const toggleSelect = (id: string) => {
    const next = new Set(selectedFiles);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedFiles(next);
  };

  const handleAdd = () => {
    const filesToAdd = newFiles.filter(f => selectedFiles.has(f.id));
    const newPhotos: Photo[] = filesToAdd.map((f, i) => ({
      id: `p-sync-${Date.now()}-${i}`,
      fileName: f.fileName,
      filePath: `${folder?.path}/${f.fileName}`,
      thumbnailUrl: `https://picsum.photos/seed/${f.fileName}/800/600`,
      cameraModel: 'Fujifilm X-T5',
      lensModel: 'XF35mmF1.4 R',
      dateTime: new Date(f.date).toISOString(),
      exposureTime: '1/250',
      fNumber: 'f/2.8',
      iso: 400,
      focalLength: '35mm',
      filmMode: f.filmMode,
      whiteBalance: 'Auto',
      dynamicRange: '100%',
      sharpness: '0',
      saturation: '0',
      contrast: '0',
      clarity: '0',
      shadowTone: '0',
      highlightTone: '0',
      noiseReduction: '0',
      grainEffect: 'Off',
      colorChromeEffect: 'Off',
      colorChromeEffectBlue: 'Off',
      isFavorite: false,
      isHidden: false,
      rating: 0,
      tags: [],
      ownerId: user?.uid || 'demo',
      recipeId: '',
      folderId: folderId
    }));

    setPhotos(prev => [...prev, ...newPhotos]);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="glass w-full max-w-xl rounded-[2.5rem] overflow-hidden shadow-2xl"
      >
        <div className="p-8 border-b border-[var(--border-color)] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center">
              <RefreshCw className={cn("w-6 h-6 text-blue-500", scanning && "animate-spin")} />
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight">Syncing Folder</h2>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                Scanning {folder?.name} for new files
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-500/10 rounded-2xl transition-all">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-10 space-y-6">
          {scanning ? (
            <div className="py-20 flex flex-col items-center justify-center space-y-6">
              <div className="w-16 h-16 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin" />
              <p className="text-sm font-black text-slate-400 uppercase tracking-widest animate-pulse">Identifying new files...</p>
            </div>
          ) : (
            <>
              <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                {newFiles.length > 0 ? (
                  newFiles.map(file => (
                    <div 
                      key={file.id}
                      onClick={() => toggleSelect(file.id)}
                      className={cn(
                        "p-4 rounded-2xl border transition-all cursor-pointer flex items-center gap-4",
                        selectedFiles.has(file.id) 
                          ? "bg-blue-500/10 border-blue-500/30" 
                          : "bg-slate-500/5 border-[var(--border-color)] hover:border-slate-400"
                      )}
                    >
                      <div className={cn(
                        "w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all",
                        selectedFiles.has(file.id) ? "bg-blue-500 border-blue-500" : "border-slate-500/20"
                      )}>
                        {selectedFiles.has(file.id) && <Check className="w-4 h-4 text-white" />}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-black tracking-tight">{file.fileName}</p>
                        <div className="flex gap-3 mt-1">
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{file.date}</span>
                          <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest">{file.filmMode}</span>
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{file.size}</span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-12 text-center space-y-3">
                    <div className="w-16 h-16 bg-slate-500/5 rounded-full flex items-center justify-center mx-auto">
                      <Check className="w-8 h-8 text-slate-300" />
                    </div>
                    <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Everything is up to date</p>
                  </div>
                )}
              </div>

              <div className="pt-6 flex gap-4">
                <button 
                  onClick={onClose}
                  className="flex-1 py-4 bg-slate-500/5 hover:bg-slate-500/10 rounded-2xl text-sm font-black transition-all border border-[var(--border-color)]"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAdd}
                  disabled={selectedFiles.size === 0}
                  className="flex-[2] py-4 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-2xl text-sm font-black shadow-xl shadow-blue-500/20 transition-all flex items-center justify-center gap-3"
                >
                  <Plus className="w-5 h-5" />
                  Add {selectedFiles.size} Selected Files
                </button>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function TimelineView({ photos, onPhotoClick, onSearchDate }: { 
  photos: Photo[], 
  onPhotoClick: (p: Photo) => void, 
  onSearchDate: (date: string) => void 
}) {
  const [collapsedYears, setCollapsedYears] = useState<Set<string>>(new Set());
  const [collapsedDates, setCollapsedDates] = useState<Set<string>>(new Set());
  const [expandedDates, setExpandedDates] = useState<Set<string>>(new Set());
  const [dateLimits, setDateLimits] = useState<Record<string, number>>({});

  const INITIAL_GRID_LIMIT = 24;
  const LOAD_MORE_STEP = 24;

  // Group photos by Year, then by Date
  const groupedByYear = useMemo(() => {
    return photos.reduce((acc, p) => {
      const d = new Date(p.dateTime || '');
      const year = d.getFullYear().toString();
      const dateKey = d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
      
      if (!acc[year]) acc[year] = {};
      if (!acc[year][dateKey]) acc[year][dateKey] = [];
      acc[year][dateKey].push(p);
      return acc;
    }, {} as Record<string, Record<string, Photo[]>>);
  }, [photos]);

  const sortedYears = useMemo(() => Object.keys(groupedByYear).sort((a, b) => b.localeCompare(a)), [groupedByYear]);

  // Initialize collapsedDates: only the very first date of the timeline is expanded by default
  useEffect(() => {
    const newCollapsed = new Set<string>();
    let isFirst = true;
    sortedYears.forEach(year => {
      const dates = Object.keys(groupedByYear[year]).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
      dates.forEach(date => {
        if (isFirst) {
          isFirst = false;
        } else {
          newCollapsed.add(date);
        }
      });
    });
    setCollapsedDates(newCollapsed);
  }, [sortedYears, groupedByYear]);

  const toggleYearCollapse = (year: string) => {
    const newCollapsed = new Set(collapsedYears);
    if (newCollapsed.has(year)) {
      newCollapsed.delete(year);
    } else {
      newCollapsed.add(year);
    }
    setCollapsedYears(newCollapsed);
  };

  const toggleDateCollapse = (date: string) => {
    const newCollapsed = new Set(collapsedDates);
    if (newCollapsed.has(date)) {
      newCollapsed.delete(date);
    } else {
      newCollapsed.add(date);
    }
    setCollapsedDates(newCollapsed);
  };

  const toggleDateExpand = (date: string) => {
    const newExpanded = new Set(expandedDates);
    if (newExpanded.has(date)) {
      newExpanded.delete(date);
    } else {
      newExpanded.add(date);
      if (!dateLimits[date]) {
        setDateLimits(prev => ({ ...prev, [date]: INITIAL_GRID_LIMIT }));
      }
    }
    setExpandedDates(newExpanded);
  };

  const loadMorePhotos = (date: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDateLimits(prev => ({ ...prev, [date]: (prev[date] || INITIAL_GRID_LIMIT) + LOAD_MORE_STEP }));
  };

  const flattenedTimeline = useMemo(() => {
    const list: (
      | { type: 'year', year: string, count: number }
      | { type: 'date', date: string, items: Photo[] }
    )[] = [];
    
    sortedYears.forEach(year => {
      const isYearCollapsed = collapsedYears.has(year);
      const dateGroups = groupedByYear[year];
      const sortedDates = Object.keys(dateGroups).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
      
      list.push({ 
        type: 'year', 
        year, 
        count: Object.values(dateGroups).flat().length 
      });

      if (!isYearCollapsed) {
        sortedDates.forEach(date => {
          list.push({ 
            type: 'date', 
            date, 
            items: dateGroups[date] 
          });
        });
      }
    });
    return list;
  }, [sortedYears, groupedByYear, collapsedYears]);

  if (photos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-32 space-y-6 text-slate-400">
        <div className="w-20 h-20 bg-slate-500/5 rounded-full flex items-center justify-center">
          <Clock className="w-10 h-10 opacity-20" />
        </div>
        <div className="text-center space-y-1">
          <p className="font-black text-lg">No Timeline Data</p>
          <p className="text-xs font-bold uppercase tracking-widest opacity-60">Import photos to see your journey</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full relative">
      {/* Main Timeline Line */}
      <div className="absolute left-12 top-0 bottom-0 w-px bg-gradient-to-b from-blue-500/50 via-slate-500/10 to-transparent z-0" />

      <div className="flex justify-end pr-8 pt-8 relative z-10">
        <button 
          onClick={() => {
            if (collapsedYears.size === sortedYears.length) {
              setCollapsedYears(new Set());
            } else {
              setCollapsedYears(new Set(sortedYears));
            }
          }}
          className="text-[10px] font-black text-blue-500 uppercase tracking-widest hover:text-blue-600 transition-colors flex items-center gap-2 bg-blue-500/5 px-4 py-2 rounded-full border border-blue-500/10"
        >
          {collapsedYears.size === sortedYears.length ? 'Expand All Years' : 'Collapse All Years'}
        </button>
      </div>

      <Virtuoso
        data={flattenedTimeline}
        itemContent={(index, item) => {
          if (item.type === 'year') {
            const isYearCollapsed = collapsedYears.has(item.year);
            return (
              <div className="relative pl-8 pr-8 py-8 bg-[var(--bg-primary)]">
                <div 
                  className="flex items-center gap-6 group cursor-pointer" 
                  onClick={() => toggleYearCollapse(item.year)}
                >
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-white border-4 border-blue-500 shadow-lg shadow-blue-500/20 z-10" />
                  <div className="flex items-baseline gap-4">
                    <h2 className="text-5xl font-black tracking-tighter text-slate-900 dark:text-white group-hover:text-blue-500 transition-colors">{item.year}</h2>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                      {item.count} Photos
                    </span>
                  </div>
                  <div className="flex-1 h-px bg-gradient-to-r from-slate-500/10 to-transparent" />
                  <motion.div
                    animate={{ rotate: isYearCollapsed ? -90 : 0 }}
                    className="p-2 hover:bg-slate-500/5 rounded-xl transition-all"
                  >
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                  </motion.div>
                </div>
              </div>
            );
          }

          const date = item.date;
          const items = item.items;
          const isExpanded = expandedDates.has(date);
          const isDateCollapsed = collapsedDates.has(date);

          return (
            <div className="relative pl-14 pr-8 py-6 bg-[var(--bg-primary)]">
              <div className="space-y-8">
                <div 
                  className="flex items-center gap-4 cursor-pointer group/date"
                  onClick={() => toggleDateCollapse(date)}
                >
                  <div className="w-3 h-3 rounded-full bg-blue-500/30 group-hover/date:bg-blue-500 transition-colors" />
                  <div className="flex flex-col">
                    <h3 className="text-lg font-black tracking-tight text-slate-600 dark:text-slate-300 group-hover/date:text-blue-500 transition-colors">{date}</h3>
                    {(() => {
                      const locations = Array.from(new Set(items.map(p => p.location).filter(Boolean)));
                      if (locations.length > 0) {
                        return (
                          <div className="flex items-center gap-2 mt-1">
                            <Target className="w-3 h-3 text-blue-500/60" />
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest truncate max-w-[200px]">
                              {locations.join(' • ')}
                            </span>
                          </div>
                        );
                      }
                      return null;
                    })()}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="px-3 py-1 bg-slate-500/5 rounded-full border border-[var(--border-color)]">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        {items.length} Photos
                      </span>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        const d = new Date(date);
                        const filterDateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                        onSearchDate(filterDateStr);
                      }}
                      className="p-2 hover:bg-blue-500/10 rounded-xl text-blue-500 transition-all group/jump"
                      title="View in Gallery"
                    >
                      <ExternalLink className="w-4 h-4 group-hover/jump:scale-110 transition-transform" />
                    </button>
                  </div>
                  <motion.div
                    animate={{ rotate: isDateCollapsed ? -90 : 0 }}
                    className="opacity-0 group-hover/date:opacity-100 transition-opacity"
                  >
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  </motion.div>
                </div>

                <AnimatePresence mode="wait">
                  {!isDateCollapsed && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <AnimatePresence mode="wait">
                        {!isExpanded ? (
                          <motion.div
                            key="stack"
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="relative h-72 w-full max-w-md cursor-pointer group ml-6"
                            onClick={() => toggleDateExpand(date)}
                          >
                            {items.slice(0, 4).map((photo, idx) => (
                              <motion.div
                                key={photo.id}
                                className="absolute inset-0 rounded-[2.5rem] overflow-hidden border-4 border-white dark:border-slate-800 shadow-2xl"
                                animate={{ 
                                  zIndex: 4 - idx,
                                  x: idx * 24,
                                  y: idx * 14,
                                  rotate: idx === 0 ? 0 : idx === 1 ? 8 : idx === 2 ? -8 : 4,
                                  scale: 1 - idx * 0.05,
                                }}
                                whileHover={{
                                  x: idx * 36,
                                  y: idx * 20,
                                  rotate: idx === 0 ? -2 : idx === 1 ? 15 : idx === 2 ? -15 : 8,
                                  transition: { type: "spring", stiffness: 300, damping: 20 }
                                }}
                              >
                                <img src={photo.thumbnailUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="" loading="lazy" />
                                {idx === 0 && (
                                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-10">
                                    <div className="flex items-center gap-2 mb-2">
                                      <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                                      <span className="text-white text-[10px] font-black uppercase tracking-widest opacity-80">Click to reveal album</span>
                                    </div>
                                    <h4 className="text-white text-2xl font-black tracking-tight">{items.length} Photos</h4>
                                    <p className="text-white/40 text-[8px] font-bold uppercase tracking-widest mt-2">{items[0].filmMode} • {items[0].cameraModel}</p>
                                  </div>
                                )}
                              </motion.div>
                            ))}
                            <div className="absolute -inset-10 bg-blue-500/5 blur-[100px] rounded-full -z-10 opacity-0 group-hover:opacity-100 transition-opacity" />
                          </motion.div>
                        ) : (
                          <motion.div
                            key="grid"
                            initial={{ opacity: 0, y: 30 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 30 }}
                            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 ml-6"
                          >
                            {items.slice(0, dateLimits[date] || INITIAL_GRID_LIMIT).map((photo, pIdx) => (
                              <motion.div
                                key={photo.id}
                                initial={{ opacity: 0, scale: 0.8 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: pIdx * 0.01 }}
                                whileHover={{ scale: 1.05, y: -8 }}
                                whileTap={{ scale: 0.95 }}
                                onClick={() => onPhotoClick(photo)}
                                className="aspect-square rounded-3xl overflow-hidden cursor-pointer border border-[var(--border-color)] shadow-sm relative group bg-slate-500/5"
                              >
                                <img src={photo.thumbnailUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="" loading="lazy" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                                  <p className="text-[8px] font-black text-white truncate uppercase tracking-widest">{photo.filmMode}</p>
                                </div>
                                <div className="absolute top-3 right-3 p-2 bg-black/40 backdrop-blur-md rounded-xl border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Eye className="w-3 h-3 text-white" />
                                </div>
                              </motion.div>
                            ))}
                            
                            {items.length > (dateLimits[date] || INITIAL_GRID_LIMIT) && (
                              <motion.button
                                whileHover={{ scale: 1.05, backgroundColor: 'rgba(59, 130, 246, 0.1)' }}
                                whileTap={{ scale: 0.95 }}
                                onClick={(e) => loadMorePhotos(date, e)}
                                className="aspect-square rounded-3xl border-2 border-dashed border-blue-500/30 bg-blue-500/5 flex flex-col items-center justify-center gap-3 transition-all group"
                              >
                                <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center group-hover:bg-blue-500 group-hover:text-white transition-all">
                                  <Plus className="w-6 h-6 text-blue-500 group-hover:text-white" />
                                </div>
                                <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Load More</span>
                                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                                  {items.length - (dateLimits[date] || INITIAL_GRID_LIMIT)} remaining
                                </span>
                              </motion.button>
                            )}

                            <motion.button 
                              whileHover={{ scale: 1.05, backgroundColor: 'rgba(59, 130, 246, 0.1)' }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => toggleDateExpand(date)}
                              className="aspect-square rounded-3xl border-2 border-dashed border-slate-500/30 bg-slate-500/5 flex flex-col items-center justify-center gap-3 transition-all group"
                            >
                              <div className="w-12 h-12 rounded-full bg-slate-500/10 flex items-center justify-center group-hover:bg-slate-500 group-hover:text-white transition-all">
                                <ChevronUp className="w-6 h-6 text-slate-400 group-hover:text-white" />
                              </div>
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Collapse</span>
                            </motion.button>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          );
        }}
      />
    </div>
  );
}

function TagsView({ tags, setTags, photos, setPhotos, onTagClick }: { 
  tags: Tag[], 
  setTags: React.Dispatch<React.SetStateAction<Tag[]>>, 
  photos: Photo[], 
  setPhotos: React.Dispatch<React.SetStateAction<Photo[]>>,
  onTagClick: (tagName: string) => void 
}) {
  const [isCreating, setIsCreating] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#3b82f6');

  const handleCreateTag = () => {
    if (!newTagName.trim()) return;
    const newTag: Tag = {
      id: `t-${Date.now()}`,
      name: newTagName.trim(),
      color: newTagColor,
      ownerId: 'demo'
    };
    setTags(prev => [...prev, newTag]);
    setNewTagName('');
    setIsCreating(false);
  };

  const handleDeleteTag = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const tagToDelete = tags.find(t => t.id === id);
    if (!tagToDelete) return;

    if (confirm(`Are you sure you want to delete "${tagToDelete.name}"? This will remove it from all photos.`)) {
      setTags(prev => prev.filter(t => t.id !== id));
      setPhotos(prev => prev.map(p => ({
        ...p,
        tags: p.tags?.filter(t => t !== tagToDelete.name) || []
      })));
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between">
        <h2 className="text-4xl font-black tracking-tighter">Tags Library</h2>
        <div className="flex items-center gap-6">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">
            {tags.length} active tags
          </div>
          <button 
            onClick={() => setIsCreating(true)}
            className="bg-blue-500 text-white px-6 py-3 rounded-2xl text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-lg shadow-blue-500/20 hover:scale-105 active:scale-95"
          >
            <Plus className="w-5 h-5" />
            New Tag
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
        {tags.map((tag, index) => (
          <TagCard 
            key={tag.id} 
            tag={tag} 
            photos={photos} 
            index={index} 
            onClick={() => onTagClick(tag.name)} 
            onDelete={(e) => handleDeleteTag(tag.id, e)}
          />
        ))}

        {/* Add New Tag Placeholder */}
        <motion.div
          whileHover={{ y: -10 }}
          className="group cursor-pointer"
          onClick={() => setIsCreating(true)}
        >
          <div className="h-64 mb-6 rounded-3xl border-4 border-dashed border-slate-500/10 flex flex-col items-center justify-center space-y-4 group-hover:border-blue-500/30 group-hover:bg-blue-500/5 transition-all">
            <div className="w-16 h-16 rounded-full bg-slate-500/5 flex items-center justify-center group-hover:bg-blue-500/10 transition-all">
              <Plus className="w-8 h-8 text-slate-400 group-hover:text-blue-500 transition-all" />
            </div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-blue-500 transition-all">Create New Tag</span>
          </div>
        </motion.div>
      </div>

      {/* Create Tag Modal */}
      <AnimatePresence>
        {isCreating && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="glass w-full max-w-md rounded-[2.5rem] overflow-hidden shadow-2xl"
            >
              <div className="p-8 border-b border-[var(--border-color)] flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center">
                    <Tags className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black tracking-tight">New Tag</h2>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Create a custom label</p>
                  </div>
                </div>
                <button onClick={() => setIsCreating(false)} className="p-2 hover:bg-slate-500/10 rounded-2xl transition-all">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-10 space-y-8">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tag Name</label>
                  <input 
                    type="text" 
                    className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-bold"
                    placeholder="e.g. Summer 2024"
                    value={newTagName}
                    onChange={e => setNewTagName(e.target.value)}
                    autoFocus
                  />
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tag Color</label>
                  <div className="flex flex-wrap gap-3">
                    {['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#64748b', '#1e293b'].map(color => (
                      <button
                        key={color}
                        onClick={() => setNewTagColor(color)}
                        className={cn(
                          "w-10 h-10 rounded-full border-4 transition-all",
                          newTagColor === color ? "border-blue-500 scale-110" : "border-transparent hover:scale-105"
                        )}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                    <input 
                      type="color" 
                      value={newTagColor}
                      onChange={e => setNewTagColor(e.target.value)}
                      className="w-10 h-10 rounded-full overflow-hidden border-none cursor-pointer"
                    />
                  </div>
                </div>

                <button 
                  onClick={handleCreateTag}
                  disabled={!newTagName.trim()}
                  className="w-full py-5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-2xl font-black shadow-lg shadow-blue-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                >
                  <Check className="w-5 h-5" />
                  Create Tag
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TagCard({ tag, photos, index, onClick, onDelete }: { tag: Tag, photos: Photo[], index: number, onClick: () => void, onDelete: (e: React.MouseEvent) => void }) {
  const [isHovered, setIsHovered] = useState(false);
  const tagPhotos = photos.filter(p => p.tags?.includes(tag.name));
  const previewPhotos = tagPhotos.slice(0, 3);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -10 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      className="group cursor-pointer relative"
    >
      <button 
        onClick={onDelete}
        className="absolute top-4 right-4 z-20 p-2 bg-red-500 text-white rounded-xl opacity-0 group-hover:opacity-100 transition-all hover:bg-red-600 shadow-lg"
      >
        <Trash2 className="w-4 h-4" />
      </button>

      <div className="relative h-64 mb-6">
        {/* Stacked Photos Effect */}
        {previewPhotos.length > 0 ? (
          previewPhotos.map((photo, i) => (
            <motion.div
              key={photo.id}
              className="absolute inset-0 rounded-3xl overflow-hidden border-4 border-white dark:border-slate-800 shadow-xl"
              animate={{ 
                zIndex: 3 - i,
                rotate: i === 0 ? 0 : i === 1 ? (isHovered ? 12 : 6) : (isHovered ? -12 : -6),
                x: i === 0 ? 0 : i === 1 ? (isHovered ? 30 : 15) : (isHovered ? -30 : -15),
                y: i === 0 ? 0 : i === 1 ? (isHovered ? 20 : 10) : (isHovered ? 10 : 5),
                scale: 1 - (i * 0.05)
              }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <img src={photo.thumbnailUrl} className="w-full h-full object-cover" alt="" />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
            </motion.div>
          ))
        ) : (
          <div className="absolute inset-0 rounded-3xl bg-slate-500/5 border-4 border-dashed border-slate-500/20 flex items-center justify-center">
            <Tags className="w-12 h-12 text-slate-500/20" />
          </div>
        )}
        
        {/* Tag Badge */}
        <div 
          className="absolute bottom-4 left-1/2 -translate-x-1/2 px-6 py-2 rounded-full shadow-lg text-white font-black text-xs uppercase tracking-widest z-10"
          style={{ backgroundColor: tag.color || '#3b82f6' }}
        >
          {tag.name}
        </div>
      </div>

      <div className="text-center space-y-1">
        <h3 className="font-black text-xl tracking-tight group-hover:text-blue-500 transition-colors">{tag.name}</h3>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
          {tagPhotos.length} photos in collection
        </p>
      </div>
    </motion.div>
  );
}

function RecipeView({ recipes, photos, user, theme, onAddRecipe }: { recipes: Recipe[], photos: Photo[], user: User, theme: string, onAddRecipe: (r: Recipe) => void }) {
  const [isCreating, setIsCreating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRecipeId, setSelectedRecipeId] = useState<string | null>(null);
  const [newRecipe, setNewRecipe] = useState<Partial<Recipe>>({
    name: '',
    filmMode: 'Classic Chrome',
    whiteBalance: 'Auto',
    whiteBalanceShift: '0, 0',
    dynamicRange: 'DR100',
    sharpness: '0',
    color: '0',
    highlightTone: '0',
    shadowTone: '0',
    noiseReduction: '0',
    clarity: '0',
    grainEffect: 'Off, Off',
    colorChromeEffect: 'Off',
    colorChromeEffectBlue: 'Off',
    isFavorite: false,
    ownerId: user.uid
  });

  const handleCreate = async () => {
    if (!newRecipe.name) return;
    const recipe: Recipe = {
      ...newRecipe as Recipe,
      id: `r-${Date.now()}`
    };
    onAddRecipe(recipe);
    setIsCreating(false);
    setNewRecipe({ 
      name: '', 
      filmMode: 'Classic Chrome', 
      whiteBalance: 'Auto',
      whiteBalanceShift: '0, 0',
      dynamicRange: 'DR100',
      sharpness: '0',
      color: '0',
      highlightTone: '0',
      shadowTone: '0',
      noiseReduction: '0',
      clarity: '0',
      grainEffect: 'Off, Off',
      colorChromeEffect: 'Off',
      colorChromeEffectBlue: 'Off',
      isFavorite: false, 
      ownerId: user.uid 
    });
  };

  const filteredRecipes = recipes.filter(r => 
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.filmMode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedRecipe = recipes.find(r => r.id === selectedRecipeId);
  const recipePhotos = photos.filter(p => p.recipeId === selectedRecipeId);

  return (
    <div className="h-full flex flex-col space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 flex-shrink-0">
        <div>
          <h2 className="text-3xl font-black tracking-tight">Film Recipes</h2>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Manage your custom film simulations</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative group flex-1 md:w-64">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
            <input 
              type="text" 
              placeholder="Search recipes..."
              className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-2xl pl-12 pr-4 py-3 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
          <button 
            onClick={() => setIsCreating(true)}
            className="bg-blue-500 text-white px-6 py-3 rounded-2xl text-sm font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-lg shadow-blue-500/20 hover:scale-105 active:scale-95"
          >
            <Plus className="w-5 h-5" />
            New
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Recipe List - Scrollable */}
        <div className={cn(
          "h-full overflow-y-auto pr-4 custom-scrollbar space-y-6", 
          selectedRecipeId ? "lg:col-span-4" : "lg:col-span-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 space-y-0"
        )}>
          {filteredRecipes.map(recipe => (
            <motion.div 
              layout
              key={recipe.id} 
              onClick={() => setSelectedRecipeId(recipe.id === selectedRecipeId ? null : recipe.id)}
              className={cn(
                "glass-card rounded-3xl p-8 space-y-6 group cursor-pointer transition-all border-2",
                selectedRecipeId === recipe.id ? "border-blue-500 ring-4 ring-blue-500/10" : "border-transparent hover:border-blue-500/30"
              )}
            >
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h3 className="font-black text-xl tracking-tight">{recipe.name}</h3>
                  <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest">{recipe.filmMode}</p>
                </div>
                <Heart className={cn("w-6 h-6 transition-all", recipe.isFavorite ? "text-red-500 fill-red-500" : "text-slate-300 group-hover:text-red-500/50")} />
              </div>
              
              {!selectedRecipeId && (
                <div className="grid grid-cols-2 gap-3">
                  <FilmTag label="WB" value={recipe.whiteBalance} />
                  <FilmTag label="DR" value={recipe.dynamicRange} />
                  <FilmTag label="Sharp" value={recipe.sharpness} />
                  <FilmTag label="Color" value={recipe.color} />
                </div>
              )}

              <div className="pt-6 border-t border-[var(--border-color)] flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  {photos.filter(p => p.recipeId === recipe.id).length} photos
                </span>
                <div className="flex items-center gap-2 text-blue-500">
                  <span className="text-[10px] font-black uppercase tracking-widest">Details</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Recipe Details Panel - Fixed/Sticky */}
        {selectedRecipeId && selectedRecipe && (() => {
          // Parse WB Shift
          const wbShift = selectedRecipe.whiteBalanceShift?.split(',').map(s => s.trim()) || [];
          const wbRed = wbShift[0] || '0';
          const wbBlue = wbShift[1] || '0';

          // Parse Grain Effect
          const grainParts = selectedRecipe.grainEffect?.split(',').map(s => s.trim()) || [];
          const grainRoughness = grainParts[0] || 'Off';
          const grainSize = grainParts[1] || 'Off';

          return (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="lg:col-span-8 h-full overflow-y-auto pr-4 custom-scrollbar"
            >
              <div className="glass-card rounded-[2.5rem] p-10 space-y-10">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center">
                      <Film className="w-8 h-8 text-blue-500" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-black tracking-tight">{selectedRecipe.name}</h2>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="px-3 py-1 bg-blue-500/10 text-blue-500 rounded-full text-[10px] font-black uppercase tracking-widest">
                          {selectedRecipe.filmMode}
                        </span>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Created by you</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <button className="p-4 bg-slate-500/5 hover:bg-slate-500/10 rounded-2xl transition-all border border-[var(--border-color)]">
                      <Edit3 className="w-5 h-5 text-slate-400" />
                    </button>
                    <button className="p-4 bg-slate-500/5 hover:bg-slate-500/10 rounded-2xl transition-all border border-[var(--border-color)]">
                      <Share2 className="w-5 h-5 text-slate-400" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'White Balance', value: selectedRecipe.whiteBalance },
                    { label: 'Dynamic Range', value: selectedRecipe.dynamicRange },
                    { label: 'Highlight', value: selectedRecipe.highlightTone },
                    { label: 'Shadow', value: selectedRecipe.shadowTone },
                    { label: 'Color', value: selectedRecipe.color },
                    { label: 'Sharpness', value: selectedRecipe.sharpness },
                    { label: 'Noise Reduction', value: selectedRecipe.noiseReduction },
                    { label: 'Clarity', value: selectedRecipe.clarity },
                    { label: 'Grain Roughness', value: grainRoughness },
                    { label: 'Grain Size', value: grainSize },
                    { label: 'Color Chrome', value: selectedRecipe.colorChromeEffect },
                    { label: 'FX Blue', value: selectedRecipe.colorChromeEffectBlue },
                    { label: 'WB Red', value: wbRed },
                    { label: 'WB Blue', value: wbBlue },
                  ].map(stat => (
                    <FilmSettingCard key={stat.label} label={stat.label} value={stat.value} />
                  ))}
                </div>

                <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Photos using this recipe</h3>
                  <button className="text-[10px] font-black text-blue-500 uppercase tracking-widest hover:underline">View All</button>
                </div>
                <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                  {recipePhotos.slice(0, 5).map(photo => (
                    <div key={photo.id} className="aspect-square rounded-2xl overflow-hidden bg-slate-500/10 group relative">
                      <img src={photo.thumbnailUrl} alt="" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Eye className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  ))}
                  {recipePhotos.length === 0 && (
                    <div className="col-span-full py-10 text-center border-2 border-dashed border-slate-500/10 rounded-3xl">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">No photos yet</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        );
      })()}
    </div>

      <AnimatePresence>
        {isCreating && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="glass w-full max-w-3xl max-h-[90vh] overflow-hidden rounded-[2.5rem] shadow-2xl flex flex-col"
            >
              <div className="p-8 border-b border-[var(--border-color)] flex items-center justify-between flex-shrink-0">
                <h2 className="text-2xl font-black tracking-tight">New Recipe</h2>
                <button onClick={() => setIsCreating(false)} className="p-2 hover:bg-slate-500/10 rounded-2xl transition-all">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="p-10 space-y-10 overflow-y-auto custom-scrollbar">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Recipe Name</label>
                  <input 
                    type="text" 
                    className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-bold"
                    placeholder="e.g. Kodachrome 64"
                    value={newRecipe.name}
                    onChange={e => setNewRecipe({ ...newRecipe, name: e.target.value })}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Film Mode</label>
                      <CustomSelect 
                        value={newRecipe.filmMode || ''}
                        onChange={(val) => setNewRecipe({ ...newRecipe, filmMode: val })}
                        options={FILM_MODES.map(m => ({ label: m, value: m }))}
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">White Balance</label>
                      <input 
                        type="text" 
                        className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-2xl px-6 py-4 focus:outline-none font-bold"
                        placeholder="Auto"
                        value={newRecipe.whiteBalance}
                        onChange={e => setNewRecipe({ ...newRecipe, whiteBalance: e.target.value })}
                      />
                    </div>
                    <Slider 
                      label="Sharpness" 
                      value={Number(newRecipe.sharpness || 0)} 
                      onChange={(val) => setNewRecipe({ ...newRecipe, sharpness: val.toString() })} 
                    />
                    <Slider 
                      label="Color" 
                      value={Number(newRecipe.color || 0)} 
                      onChange={(val) => setNewRecipe({ ...newRecipe, color: val.toString() })} 
                    />
                    <Slider 
                      label="Noise Reduction" 
                      value={Number(newRecipe.noiseReduction || 0)} 
                      onChange={(val) => setNewRecipe({ ...newRecipe, noiseReduction: val.toString() })} 
                    />
                    <Slider 
                      label="Clarity" 
                      value={Number(newRecipe.clarity || 0)} 
                      onChange={(val) => setNewRecipe({ ...newRecipe, clarity: val.toString() })} 
                    />
                  </div>

                  <div className="space-y-6">
                    <Slider 
                      label="Highlight" 
                      value={Number(newRecipe.highlightTone || 0)} 
                      onChange={(val) => setNewRecipe({ ...newRecipe, highlightTone: val.toString() })} 
                    />
                    <Slider 
                      label="Shadow" 
                      value={Number(newRecipe.shadowTone || 0)} 
                      onChange={(val) => setNewRecipe({ ...newRecipe, shadowTone: val.toString() })} 
                    />
                    <Switch 
                      label="Chrome FX" 
                      checked={newRecipe.colorChromeEffect === 'On'} 
                      onChange={(val) => setNewRecipe({ ...newRecipe, colorChromeEffect: val ? 'On' : 'Off' })} 
                    />
                    <Switch 
                      label="FX Blue" 
                      checked={newRecipe.colorChromeEffectBlue === 'On'} 
                      onChange={(val) => setNewRecipe({ ...newRecipe, colorChromeEffectBlue: val ? 'On' : 'Off' })} 
                    />
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">WB Shift (R, B)</label>
                      <input 
                        type="text" 
                        className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-2xl px-6 py-4 focus:outline-none font-bold"
                        placeholder="0, 0"
                        value={newRecipe.whiteBalanceShift}
                        onChange={e => setNewRecipe({ ...newRecipe, whiteBalanceShift: e.target.value })}
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Grain Effect (Roughness, Size)</label>
                      <input 
                        type="text" 
                        className="w-full bg-slate-500/5 border border-[var(--border-color)] rounded-2xl px-6 py-4 focus:outline-none font-bold"
                        placeholder="Off, Off"
                        value={newRecipe.grainEffect}
                        onChange={e => setNewRecipe({ ...newRecipe, grainEffect: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-8 border-t border-[var(--border-color)] flex-shrink-0">
                <button 
                  onClick={handleCreate}
                  className="w-full py-5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-2xl font-black shadow-lg shadow-blue-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  Create Recipe
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string, value: number, icon: React.ReactNode }) {
  return (
    <div className="glass-card p-8 rounded-3xl space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{label}</span>
        <div className="p-2 bg-slate-500/5 rounded-xl">
          {icon}
        </div>
      </div>
      <div className="text-4xl font-black tracking-tighter">{value}</div>
    </div>
  );
}

function StatsView({ photos, theme }: { photos: Photo[], theme: string }) {
  const filmStats = FILM_MODES.map(mode => ({
    name: mode,
    count: photos.filter(p => p.filmMode === mode).length
  })).filter(s => s.count > 0).sort((a, b) => b.count - a.count);

  const cameraStats = Array.from(new Set(photos.map(p => p.cameraModel))).map(model => ({
    name: model || 'Unknown',
    count: photos.filter(p => p.cameraModel === model).length
  })).sort((a, b) => b.count - a.count);

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <StatCard label="Total Photos" value={photos.length} icon={<Images className="w-6 h-6 text-blue-500" />} />
        <StatCard label="Favorites" value={photos.filter(p => p.isFavorite).length} icon={<Heart className="w-6 h-6 text-red-500" />} />
        <StatCard label="Cameras" value={cameraStats.length} icon={<Camera className="w-6 h-6 text-green-500" />} />
        <StatCard label="Film Modes" value={filmStats.length} icon={<FlaskConical className="w-6 h-6 text-purple-500" />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="glass-card p-10 rounded-3xl space-y-8">
          <h3 className="font-black text-xl tracking-tight">Film Mode Usage</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={filmStats} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? "#333" : "#e2e8f0"} horizontal={false} />
                <XAxis type="number" stroke="#94a3b8" fontSize={12} />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={10} width={100} />
                <Tooltip 
                  contentStyle={{ backgroundColor: theme === 'dark' ? '#111' : '#fff', border: 'none', borderRadius: '16px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                  itemStyle={{ color: '#3b82f6', fontWeight: 'bold' }}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-10 rounded-3xl space-y-8">
          <h3 className="font-black text-xl tracking-tight">Camera Distribution</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={cameraStats}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={110}
                  paddingAngle={8}
                  dataKey="count"
                >
                  {cameraStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: theme === 'dark' ? '#111' : '#fff', border: 'none', borderRadius: '16px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-6 justify-center">
            {cameraStats.map((s, i) => (
              <div key={s.name} className="flex items-center gap-3">
                <div className="w-4 h-4 rounded-full shadow-sm" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{s.name} ({s.count})</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function SettingsView({ 
  theme, 
  setTheme, 
  folders, 
  setFolders,
  cloudSyncEnabled,
  setCloudSyncEnabled
}: { 
  theme: string, 
  setTheme: (t: 'light' | 'dark') => void, 
  folders: Folder[], 
  setFolders: React.Dispatch<React.SetStateAction<Folder[]>>,
  cloudSyncEnabled: boolean,
  setCloudSyncEnabled: (v: boolean) => void
}) {
  const toggleSubfolders = (id: string) => {
    setFolders(prev => prev.map(f => f.id === id ? { ...f, includeSubfolders: !f.includeSubfolders } : f));
  };

  const removeFolder = (id: string) => {
    if (confirm('Are you sure you want to remove this folder?')) {
      setFolders(prev => prev.filter(f => f.id !== id));
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-20">
      <div className="flex items-center justify-between">
        <h2 className="text-4xl font-black tracking-tighter">Settings</h2>
      </div>

      {/* Appearance */}
      <section className="space-y-6">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Appearance</h3>
        <div className="glass-card p-8 rounded-3xl flex items-center justify-between">
          <div className="space-y-1">
            <p className="font-black">Theme Mode</p>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Switch between light and dark mode</p>
          </div>
          <button 
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-3 bg-slate-500/5 hover:bg-slate-500/10 rounded-2xl transition-all border border-[var(--border-color)]"
          >
            {theme === 'dark' ? <Star className="w-6 h-6 text-yellow-500 fill-yellow-500" /> : <Clock className="w-6 h-6 text-blue-500" />}
          </button>
        </div>
      </section>

      {/* Cache Management */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Cache Management</h3>
          <button className="text-xs font-black text-blue-500 hover:text-blue-600 uppercase tracking-widest flex items-center gap-2">
            <RefreshCw className="w-4 h-4" />
            Clear All Cache
          </button>
        </div>
        <div className="glass-card p-8 rounded-3xl space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-1">
              <p className="font-black text-lg">Cache Directory</p>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Set the folder where thumbnails and metadata are cached</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="px-4 py-3 bg-slate-500/5 rounded-xl border border-[var(--border-color)] font-mono text-[10px] text-slate-400">
                /Users/fuji/Library/Caches/FujiStore
              </div>
              <button className="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-lg shadow-blue-500/20">
                Change...
              </button>
            </div>
          </div>
          
          <div className="pt-8 border-t border-[var(--border-color)] grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cache Size</p>
              <p className="text-2xl font-black tracking-tight">1.24 GB</p>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cached Items</p>
              <p className="text-2xl font-black tracking-tight">4,821</p>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Last Cleaned</p>
              <p className="text-2xl font-black tracking-tight">2 days ago</p>
            </div>
          </div>
        </div>
      </section>

      {/* Cloud Sync */}
      <section className="space-y-6">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Cloud Sync</h3>
        <div className="glass-card p-8 rounded-3xl space-y-8">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="font-black text-lg">Enable Cloud Sync</p>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Automatically backup and sync your photos across devices</p>
            </div>
            <div 
              onClick={() => setCloudSyncEnabled(!cloudSyncEnabled)}
              className={cn(
                "w-14 h-8 rounded-full transition-all relative cursor-pointer",
                cloudSyncEnabled ? "bg-blue-500" : "bg-slate-500/20"
              )}
            >
              <div className={cn(
                "absolute top-1 w-6 h-6 bg-white rounded-full transition-all shadow-sm",
                cloudSyncEnabled ? "left-7" : "left-1"
              )} />
            </div>
          </div>

          {cloudSyncEnabled && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="pt-8 border-t border-[var(--border-color)] flex items-center justify-between"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                </div>
                <div className="space-y-0.5">
                  <p className="text-xs font-black uppercase tracking-widest">All files up to date</p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Last sync: Just now</p>
                </div>
              </div>
              <button className="px-6 py-3 bg-slate-500/5 hover:bg-slate-500/10 rounded-xl text-xs font-black uppercase tracking-widest transition-all border border-[var(--border-color)]">
                Sync Now
              </button>
            </motion.div>
          )}
        </div>
      </section>
    </div>
  );
}

function DesignPosters({ photos, recipes, tags, theme }: { photos: Photo[], recipes: Recipe[], tags: Tag[], theme: string }) {
  const exportPoster = async (id: string, fileName: string) => {
    const element = document.getElementById(id);
    if (!element) return;
    try {
      const dataUrl = await toJpeg(element, { quality: 0.95, backgroundColor: theme === 'dark' ? '#0a0a0a' : '#f8fafc' });
      const link = document.createElement('a');
      link.download = `${fileName}.jpg`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Export failed', err);
    }
  };

  const totalPhotos = photos.length;
  const favoritePhotos = photos.filter(p => p.isFavorite).length;
  const uniqueCameras = new Set(photos.map(p => p.cameraModel)).size;
  const filmModes = Array.from(new Set(photos.map(p => p.filmMode))).filter(Boolean);
  
  return (
    <div className="max-w-6xl mx-auto space-y-16 pb-32">
      <div className="flex flex-col gap-4">
        <h2 className="text-5xl font-black tracking-tighter">Design Showcase</h2>
        <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Generate and export project design posters</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Poster 1: Overview */}
        <PosterCard 
          id="poster-overview" 
          title="Project Overview" 
          onExport={() => exportPoster('poster-overview', 'fuji-project-overview')}
        >
          <div className="space-y-12">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-500/20">
                <Images className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-3xl font-black tracking-tight">Fuji Store</h3>
                <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Digital Asset Management</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-8">
              <BigStat label="Total Assets" value={totalPhotos} />
              <BigStat label="Curated" value={favoritePhotos} />
              <BigStat label="Hardware" value={uniqueCameras} unit="Cameras" />
              <BigStat label="Simulations" value={filmModes.length} />
            </div>

            <div className="pt-8 border-t border-slate-500/10">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Core Design Principles</p>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-sm font-bold"><Sparkles className="w-4 h-4 text-blue-500" /> AI-Powered Recipe Recognition</li>
                <li className="flex items-center gap-3 text-sm font-bold"><Layout className="w-4 h-4 text-blue-500" /> Professional Grid & List Views</li>
                <li className="flex items-center gap-3 text-sm font-bold"><FolderIcon className="w-4 h-4 text-blue-500" /> Hierarchical Directory Management</li>
              </ul>
            </div>
          </div>
        </PosterCard>

        {/* Poster 2: Film Simulations */}
        <PosterCard 
          id="poster-films" 
          title="Film Simulations" 
          onExport={() => exportPoster('poster-films', 'fuji-film-simulations')}
        >
          <div className="space-y-10">
            <h3 className="text-2xl font-black tracking-tight">Color Science</h3>
            <div className="space-y-4">
              {filmModes.slice(0, 6).map(mode => {
                const count = photos.filter(p => p.filmMode === mode).length;
                const percentage = (count / totalPhotos) * 100;
                return (
                  <div key={mode} className="space-y-2">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                      <span>{mode}</span>
                      <span>{count} Photos</span>
                    </div>
                    <div className="h-2 bg-slate-500/10 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${percentage}%` }}
                        className="h-full bg-blue-500"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="p-6 bg-blue-500/5 rounded-3xl border border-blue-500/10">
              <p className="text-xs font-bold leading-relaxed italic text-slate-500">
                "The soul of Fujifilm photography lies in its film simulations. This project preserves the metadata and visual integrity of every shot."
              </p>
            </div>
          </div>
        </PosterCard>

        {/* Poster 3: AI Recipes */}
        <PosterCard 
          id="poster-recipes" 
          title="AI Recipe Engine" 
          onExport={() => exportPoster('poster-recipes', 'fuji-ai-recipes')}
        >
          <div className="space-y-12">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-purple-500/10 rounded-3xl flex items-center justify-center border border-purple-500/20">
                <FlaskConical className="w-10 h-10 text-purple-500" />
              </div>
              <div className="space-y-1">
                <h3 className="text-2xl font-black tracking-tight">Recipe Recognition</h3>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Powered by Gemini 3 Flash</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {recipes.slice(0, 3).map(recipe => (
                <div key={recipe.id} className="p-4 bg-slate-500/5 rounded-2xl border border-slate-500/10 space-y-3">
                  <p className="text-[10px] font-black truncate">{recipe.name}</p>
                  <div className="flex flex-wrap gap-1">
                    <span className="text-[8px] font-black px-1.5 py-0.5 bg-blue-500/10 text-blue-500 rounded uppercase">{recipe.filmMode}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Technical Parameters Tracked</p>
              <div className="flex flex-wrap gap-2">
                {['WB Shift', 'Dynamic Range', 'Highlight Tone', 'Shadow Tone', 'Color', 'Sharpness', 'Clarity', 'Grain Effect'].map(p => (
                  <span key={p} className="px-3 py-1 bg-slate-500/5 rounded-full text-[9px] font-bold text-slate-500 border border-slate-500/10">{p}</span>
                ))}
              </div>
            </div>
          </div>
        </PosterCard>

        {/* Poster 4: Organization */}
        <PosterCard 
          id="poster-org" 
          title="Workflow & Structure" 
          onExport={() => exportPoster('poster-org', 'fuji-workflow')}
        >
          <div className="space-y-12">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-green-500" />
              </div>
              <h3 className="text-2xl font-black tracking-tight">Data Architecture</h3>
            </div>

            <div className="space-y-8">
              <div className="flex items-start gap-6">
                <div className="w-1 bg-blue-500 h-24 rounded-full" />
                <div className="space-y-6">
                  <OrgItem icon={<FolderIcon className="w-4 h-4" />} title="Directory Tree" desc="Recursive folder management with real-time photo counts." />
                  <OrgItem icon={<Clock className="w-4 h-4" />} title="Timeline View" desc="Chronological grouping with smooth layout transitions." />
                  <OrgItem icon={<Tags className="w-4 h-4" />} title="Tag Library" desc="Multi-dimensional filtering and automated categorization." />
                </div>
              </div>
            </div>

            <div className="pt-8 border-t border-slate-500/10 flex justify-between items-center">
              <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Build v1.0.4</div>
              <div className="flex -space-x-2">
                {[1,2,3].map(i => (
                  <div key={i} className="w-6 h-6 rounded-full border-2 border-[var(--bg-primary)] bg-slate-200 overflow-hidden">
                    <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i}`} alt="avatar" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </PosterCard>
      </div>
    </div>
  );
}

function PosterCard({ id, title, children, onExport }: { id: string, title: string, children: React.ReactNode, onExport: () => void }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-2">
        <h4 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">{title}</h4>
        <button 
          onClick={onExport}
          className="p-2 hover:bg-blue-500/10 rounded-xl transition-all text-blue-500 group"
          title="Export as JPG"
        >
          <Download className="w-4 h-4 group-hover:scale-110 transition-transform" />
        </button>
      </div>
      <div 
        id={id}
        className="aspect-[3/4] glass-card rounded-[3rem] p-12 relative overflow-hidden shadow-2xl border border-[var(--border-color)]"
      >
        {/* Background Accents */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl" />
        
        <div className="relative h-full flex flex-col justify-between">
          {children}
          
          <div className="mt-auto pt-12 flex items-center justify-between opacity-30">
            <span className="text-[8px] font-black uppercase tracking-[0.3em]">Fuji Store Design System</span>
            <span className="text-[8px] font-black uppercase tracking-[0.3em]">2026</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function BigStat({ label, value, unit }: { label: string, value: number, unit?: string }) {
  return (
    <div className="space-y-1">
      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
      <div className="flex items-baseline gap-2">
        <span className="text-4xl font-black tracking-tighter">{value}</span>
        {unit && <span className="text-[10px] font-bold text-slate-400 uppercase">{unit}</span>}
      </div>
    </div>
  );
}

function OrgItem({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="space-y-1">
      <div className="flex items-center gap-3">
        <div className="text-blue-500">{icon}</div>
        <p className="font-black text-sm">{title}</p>
      </div>
      <p className="text-xs text-slate-400 font-medium leading-relaxed">{desc}</p>
    </div>
  );
}

// --- Export Templates View ---
function ExportTemplates({ theme, onTryTemplate }: { theme: string, onTryTemplate: (templateId: string) => void }) {
  const templates = [
    { id: 'minimal', name: 'Minimalist', description: 'Clean, white background with centered photo and recipe below.', preview: 'https://picsum.photos/seed/minimal/400/600' },
    { id: 'magazine', name: 'Magazine', description: 'Elegant serif fonts with overlapping elements and artistic layout.', preview: 'https://picsum.photos/seed/magazine/400/600' },
    { id: 'insta', name: 'Insta-Square', description: '1:1 ratio with polaroid-style border and recipe at the bottom.', preview: 'https://picsum.photos/seed/insta/400/400' },
    { id: 'darktech', name: 'Dark Cinematic', description: 'Dark background with neon accents and technical EXIF display.', preview: 'https://picsum.photos/seed/dark/400/600' },
    { id: 'custom', name: 'Custom Design', description: 'Design your own layout, colors, and EXIF fields.', preview: 'https://picsum.photos/seed/custom/400/600' }
  ];

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-black tracking-tighter">Export Templates</h2>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">Choose a style for your recipe sharing</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {templates.map(template => (
          <motion.div 
            key={template.id}
            whileHover={{ y: -8 }}
            className="glass-card rounded-[2rem] overflow-hidden flex flex-col group"
          >
            <div className="aspect-[3/4] relative overflow-hidden bg-slate-500/5">
              <img src={template.preview} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-all duration-500" alt={template.name} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                <p className="text-white text-xs font-bold leading-relaxed">{template.description}</p>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-black">{template.name}</h3>
                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Palette className="w-4 h-4 text-blue-500" />
                </div>
              </div>
              <button 
                onClick={() => onTryTemplate(template.id)}
                className="w-full py-3 bg-slate-500/5 hover:bg-slate-500/10 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border border-[var(--border-color)]"
              >
                Try Style
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

interface CustomSettings {
  backgroundColor: string;
  textColor: string;
  fontFamily: 'sans' | 'serif' | 'mono' | 'display';
  borderRadius: number;
  padding: number;
  showExif: {
    wb: boolean;
    dr: boolean;
    iso: boolean;
    shutter: boolean;
    aperture: boolean;
    lens: boolean;
    camera: boolean;
  };
  layout: 'stacked' | 'split';
}

// --- Recipe Export Modal ---
function RecipeExportModal({ photo, onClose, theme, initialTemplate = 'minimal' }: { photo: Photo, onClose: () => void, theme: string, initialTemplate?: string }) {
  const [selectedTemplate, setSelectedTemplate] = useState(initialTemplate);
  const [exporting, setExporting] = useState(false);
  const [customSettings, setCustomSettings] = useState<CustomSettings>({
    backgroundColor: theme === 'dark' ? '#0a0a0a' : '#ffffff',
    textColor: theme === 'dark' ? '#f8fafc' : '#0f172a',
    fontFamily: 'sans',
    borderRadius: 16,
    padding: 32,
    showExif: {
      wb: true,
      dr: true,
      iso: true,
      shutter: true,
      aperture: true,
      lens: true,
      camera: true
    },
    layout: 'stacked'
  });
  const exportRef = useRef<HTMLDivElement>(null);

  const handleExport = async () => {
    if (!exportRef.current) return;
    setExporting(true);
    try {
      const dataUrl = await toJpeg(exportRef.current, { quality: 0.95, pixelRatio: 2 });
      const link = document.createElement('a');
      link.download = `FujiRecipe_${photo.fileName.split('.')[0]}.jpg`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Export failed:', err);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-2xl">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="glass w-full max-w-5xl h-[90vh] rounded-[3rem] overflow-hidden flex flex-col lg:flex-row shadow-2xl"
      >
        {/* Preview Area */}
        <div className="flex-1 bg-slate-900/50 flex items-center justify-center p-8 overflow-auto">
          <div ref={exportRef} className="shadow-2xl">
            {selectedTemplate === 'minimal' && <MinimalTemplate photo={photo} />}
            {selectedTemplate === 'magazine' && <MagazineTemplate photo={photo} />}
            {selectedTemplate === 'insta' && <InstaTemplate photo={photo} />}
            {selectedTemplate === 'darktech' && <DarkTechTemplate photo={photo} />}
            {selectedTemplate === 'custom' && <CustomTemplate photo={photo} settings={customSettings} />}
          </div>
        </div>

        {/* Controls Area */}
        <div className="w-full lg:w-96 bg-[var(--bg-primary)] border-l border-[var(--border-color)] flex flex-col">
          <div className="p-8 border-b border-[var(--border-color)] flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-black tracking-tight">Export Recipe</h2>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Select a template to share</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-500/10 rounded-xl transition-all">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-8 space-y-8">
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Choose Template</label>
              <div className="grid grid-cols-2 gap-4">
                {['minimal', 'magazine', 'insta', 'darktech', 'custom'].map(t => (
                  <button 
                    key={t}
                    onClick={() => setSelectedTemplate(t)}
                    className={cn(
                      "p-4 rounded-2xl border-2 transition-all text-left space-y-2",
                      selectedTemplate === t 
                        ? "border-blue-500 bg-blue-500/5" 
                        : "border-transparent bg-slate-500/5 hover:bg-slate-500/10"
                    )}
                  >
                    <p className="text-xs font-black uppercase tracking-widest">{t}</p>
                    <div className="w-full aspect-video bg-slate-500/10 rounded-lg flex items-center justify-center">
                      {t === 'custom' && <Settings className="w-4 h-4 opacity-40" />}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {selectedTemplate === 'custom' && (
              <div className="space-y-8 pt-4 border-t border-[var(--border-color)]">
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Colors</label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <p className="text-[10px] font-bold text-slate-500">Background</p>
                      <input 
                        type="color" 
                        value={customSettings.backgroundColor}
                        onChange={(e) => setCustomSettings(prev => ({ ...prev, backgroundColor: e.target.value }))}
                        className="w-full h-10 rounded-lg cursor-pointer bg-transparent"
                      />
                    </div>
                    <div className="space-y-2">
                      <p className="text-[10px] font-bold text-slate-500">Text</p>
                      <input 
                        type="color" 
                        value={customSettings.textColor}
                        onChange={(e) => setCustomSettings(prev => ({ ...prev, textColor: e.target.value }))}
                        className="w-full h-10 rounded-lg cursor-pointer bg-transparent"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Typography</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(['sans', 'serif', 'mono', 'display'] as const).map(f => (
                      <button
                        key={f}
                        onClick={() => setCustomSettings(prev => ({ ...prev, fontFamily: f }))}
                        className={cn(
                          "px-3 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest border transition-all",
                          customSettings.fontFamily === f ? "bg-blue-500 text-white border-blue-500" : "bg-slate-500/5 border-transparent"
                        )}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Layout</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(['stacked', 'split'] as const).map(l => (
                      <button
                        key={l}
                        onClick={() => setCustomSettings(prev => ({ ...prev, layout: l }))}
                        className={cn(
                          "px-3 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest border transition-all",
                          customSettings.layout === l ? "bg-blue-500 text-white border-blue-500" : "bg-slate-500/5 border-transparent"
                        )}
                      >
                        {l}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">EXIF Fields</label>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                    {Object.entries(customSettings.showExif).map(([key, value]) => (
                      <button
                        key={key}
                        onClick={() => setCustomSettings(prev => ({
                          ...prev,
                          showExif: { ...prev.showExif, [key]: !value }
                        }))}
                        className="flex items-center gap-2 group"
                      >
                        <div className={cn(
                          "w-4 h-4 rounded border flex items-center justify-center transition-all",
                          value ? "bg-blue-500 border-blue-500" : "border-slate-300 group-hover:border-blue-500"
                        )}>
                          {value && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">{key}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Radius & Padding</label>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>Radius</span>
                        <span>{customSettings.borderRadius}px</span>
                      </div>
                      <input 
                        type="range" min="0" max="64" value={customSettings.borderRadius}
                        onChange={(e) => setCustomSettings(prev => ({ ...prev, borderRadius: parseInt(e.target.value) }))}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span>Padding</span>
                        <span>{customSettings.padding}px</span>
                      </div>
                      <input 
                        type="range" min="16" max="128" value={customSettings.padding}
                        onChange={(e) => setCustomSettings(prev => ({ ...prev, padding: parseInt(e.target.value) }))}
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-8 border-t border-[var(--border-color)]">
            <button 
              onClick={handleExport}
              disabled={exporting}
              className="w-full py-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-3 shadow-lg shadow-blue-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {exporting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
              {exporting ? 'Generating...' : 'Download JPG'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// --- Specific Templates ---

function CustomTemplate({ photo, settings }: { photo: Photo, settings: CustomSettings }) {
  const fontClass = {
    sans: 'font-sans',
    serif: 'font-serif',
    mono: 'font-mono',
    display: 'font-display'
  }[settings.fontFamily];

  const exifFields = [
    { key: 'camera', label: 'CAMERA', value: photo.cameraModel },
    { key: 'lens', label: 'LENS', value: photo.lensModel },
    { key: 'iso', label: 'ISO', value: photo.iso },
    { key: 'shutter', label: 'SHUTTER', value: photo.exposureTime },
    { key: 'aperture', label: 'APERTURE', value: photo.fNumber },
    { key: 'wb', label: 'WB', value: photo.whiteBalance },
    { key: 'dr', label: 'DR', value: photo.dynamicRange },
  ].filter(f => settings.showExif[f.key as keyof typeof settings.showExif]);

  return (
    <div 
      className={cn(
        "w-[400px] flex flex-col",
        settings.layout === 'split' ? "flex-row h-[500px]" : "min-h-[500px]",
        fontClass
      )}
      style={{ 
        backgroundColor: settings.backgroundColor, 
        color: settings.textColor,
        padding: `${settings.padding}px`
      }}
    >
      <div className={cn(
        "overflow-hidden shadow-lg mb-6",
        settings.layout === 'split' ? "w-1/2 mb-0 mr-6 h-full" : "w-full aspect-[4/5]"
      )}
      style={{ borderRadius: `${settings.borderRadius}px` }}
      >
        <img src={photo.thumbnailUrl} className="w-full h-full object-cover" alt="" />
      </div>

      <div className={cn(
        "flex flex-col justify-center",
        settings.layout === 'split' ? "w-1/2" : "w-full"
      )}>
        <div className="mb-6">
          <h3 className="text-2xl font-black tracking-tight leading-tight">{photo.filmMode}</h3>
          <p className="text-[10px] uppercase tracking-[0.2em] opacity-50 mt-1">Fujifilm Recipe</p>
        </div>

        <div className="grid grid-cols-2 gap-x-6 gap-y-4">
          {exifFields.map(field => (
            <div key={field.key} className="space-y-0.5">
              <p className="text-[8px] font-black uppercase tracking-widest opacity-40">{field.label}</p>
              <p className="text-[11px] font-bold truncate">{field.value || 'N/A'}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-current opacity-10 flex items-center justify-between">
          <span className="text-[8px] font-black tracking-[0.3em]">FUJI STATION</span>
          <span className="text-[8px] font-black tracking-[0.3em]">CUSTOM_GEN</span>
        </div>
      </div>
    </div>
  );
}

function MinimalTemplate({ photo }: { photo: Photo }) {
  return (
    <div className="w-[400px] bg-white p-10 flex flex-col items-center space-y-8 text-slate-900 font-sans">
      <div className="w-full aspect-[4/5] overflow-hidden rounded-sm shadow-lg">
        <img src={photo.thumbnailUrl} className="w-full h-full object-cover" alt="" />
      </div>
      <div className="w-full space-y-6 text-center">
        <div className="space-y-1">
          <h3 className="text-2xl font-serif italic">{photo.filmMode}</h3>
          <p className="text-[10px] uppercase tracking-[0.3em] font-light text-slate-400">Fujifilm Recipe</p>
        </div>
        <div className="grid grid-cols-3 gap-y-4 text-[9px] uppercase tracking-widest font-bold border-t border-slate-100 pt-6">
          <div className="space-y-1">
            <p className="text-slate-300">WB</p>
            <p>{photo.whiteBalance}</p>
          </div>
          <div className="space-y-1">
            <p className="text-slate-300">DR</p>
            <p>{photo.dynamicRange}</p>
          </div>
          <div className="space-y-1">
            <p className="text-slate-300">ISO</p>
            <p>{photo.iso}</p>
          </div>
          <div className="space-y-1">
            <p className="text-slate-300">NR</p>
            <p>{photo.noiseReduction}</p>
          </div>
          <div className="space-y-1">
            <p className="text-slate-300">SHARP</p>
            <p>{photo.sharpness}</p>
          </div>
          <div className="space-y-1">
            <p className="text-slate-300">CLARITY</p>
            <p>{photo.clarity}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function MagazineTemplate({ photo }: { photo: Photo }) {
  return (
    <div className="w-[450px] bg-[#fdfcf8] p-12 flex flex-col space-y-10 text-slate-900 font-serif relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -mr-16 -mt-16" />
      <div className="z-10 space-y-2">
        <h3 className="text-5xl font-black tracking-tighter leading-none">{photo.filmMode?.split('/')[0]}</h3>
        <p className="text-sm font-sans font-black uppercase tracking-[0.4em] text-blue-600">The Fuji Journal</p>
      </div>
      <div className="w-full aspect-[3/4] overflow-hidden shadow-2xl relative">
        <img src={photo.thumbnailUrl} className="w-full h-full object-cover" alt="" />
        <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-md px-4 py-2 text-[10px] font-sans font-black uppercase tracking-widest">
          {photo.cameraModel}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-8 font-sans">
        <div className="space-y-4">
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-200 pb-2">Settings</p>
          <div className="space-y-2 text-[11px] font-bold">
            <div className="flex justify-between"><span>WB</span><span>{photo.whiteBalance}</span></div>
            <div className="flex justify-between"><span>DR</span><span>{photo.dynamicRange}</span></div>
            <div className="flex justify-between"><span>Grain</span><span>{photo.grainEffect}</span></div>
          </div>
        </div>
        <div className="space-y-4">
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-200 pb-2">Tones</p>
          <div className="space-y-2 text-[11px] font-bold">
            <div className="flex justify-between"><span>Shadow</span><span>{photo.shadowTone}</span></div>
            <div className="flex justify-between"><span>Highlight</span><span>{photo.highlightTone}</span></div>
            <div className="flex justify-between"><span>Color</span><span>{photo.saturation}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InstaTemplate({ photo }: { photo: Photo }) {
  return (
    <div className="w-[400px] aspect-square bg-slate-50 p-6 flex flex-col font-sans">
      <div className="flex-1 bg-white p-4 shadow-lg flex flex-col space-y-4">
        <div className="flex-1 overflow-hidden">
          <img src={photo.thumbnailUrl} className="w-full h-full object-cover" alt="" />
        </div>
        <div className="flex items-center justify-between px-2 pb-2">
          <div className="space-y-0.5">
            <h3 className="text-lg font-black tracking-tight">{photo.filmMode}</h3>
            <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">{photo.cameraModel} • {photo.lensModel}</p>
          </div>
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
            <div className="w-1.5 h-1.5 rounded-full bg-orange-500" />
            <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
          </div>
        </div>
      </div>
    </div>
  );
}

function DarkTechTemplate({ photo }: { photo: Photo }) {
  return (
    <div className="w-[400px] bg-slate-950 p-10 flex flex-col space-y-8 text-white font-mono">
      <div className="flex items-center justify-between border-b border-white/10 pb-6">
        <div className="space-y-1">
          <p className="text-[8px] text-blue-500 font-bold uppercase tracking-widest">System.Recipe</p>
          <h3 className="text-xl font-black tracking-tighter">{photo.filmMode?.toUpperCase()}</h3>
        </div>
        <div className="text-right">
          <p className="text-[8px] text-slate-500 uppercase tracking-widest">Status</p>
          <p className="text-[10px] text-green-500 font-bold">VERIFIED</p>
        </div>
      </div>
      <div className="w-full aspect-video overflow-hidden border border-white/10 relative">
        <img src={photo.thumbnailUrl} className="w-full h-full object-cover grayscale opacity-80" alt="" />
        <div className="absolute inset-0 border-[20px] border-transparent border-t-white/5 border-l-white/5" />
      </div>
      <div className="grid grid-cols-2 gap-6 text-[10px]">
        <div className="space-y-3">
          <div className="flex justify-between border-b border-white/5 pb-1"><span className="text-slate-500">WB_SHIFT</span><span>{photo.whiteBalanceShift || '0,0'}</span></div>
          <div className="flex justify-between border-b border-white/5 pb-1"><span className="text-slate-500">ISO_SENS</span><span>{photo.iso}</span></div>
          <div className="flex justify-between border-b border-white/5 pb-1"><span className="text-slate-500">EXP_TIME</span><span>{photo.exposureTime}</span></div>
        </div>
        <div className="space-y-3">
          <div className="flex justify-between border-b border-white/5 pb-1"><span className="text-slate-500">CHROME_FX</span><span>{photo.colorChromeEffect}</span></div>
          <div className="flex justify-between border-b border-white/5 pb-1"><span className="text-slate-500">GRAIN_FX</span><span>{photo.grainEffect}</span></div>
          <div className="flex justify-between border-b border-white/5 pb-1"><span className="text-slate-500">SHARP_LVL</span><span>{photo.sharpness}</span></div>
        </div>
      </div>
      <div className="pt-4 flex items-center gap-4 opacity-30">
        <div className="flex-1 h-[1px] bg-white" />
        <p className="text-[8px] tracking-[0.5em]">FUJIFILM_X_SERIES</p>
        <div className="flex-1 h-[1px] bg-white" />
      </div>
    </div>
  );
}
